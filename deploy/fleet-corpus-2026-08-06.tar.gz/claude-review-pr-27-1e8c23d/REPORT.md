# Review — PR #27 (issue #13: Improve duplicate link handling)

**Verdict: APPROVE — tests_passed=true**

## What the PR does
Adds a self-contained `LinkStore` (`src/linkStore.js`) whose `save(url)` is
idempotent: it trims the URL, rejects non-strings/empties with `TypeError`, and
returns the existing row instead of creating a duplicate when the normalized URL
already exists. Ships a `node:test` suite (`test/linkStore.test.js`), wires it
into `npm test` (`vitest run && node --test 'test/**/*.test.js'`), and excludes
the top-level `test/` dir from vitest so the two runners don't collide.

## Correctness
- `save()` validation and dedup logic are sound. Verified by exercising the
  module directly: exact-match-after-trim dedup — whitespace variants collapse
  to one row (id reused), distinct URLs (incl. trailing-slash) create separate
  rows. Behavior matches the docstring; no over-claimed URL canonicalization.
- `all()` returns a defensive copy (`this.rows.slice()`), so callers can't mutate
  internal state.
- ESM conversion is consistent with `"type": "module"` in the merged
  `package.json`; typecheck (`tsc --noEmit`) is clean.

## Tests (verified locally)
- `npm ci` → exit 0.
- `npm test` → vitest **5/5 pass** (`src/components/LinksPage.test.tsx`), then
  node:test **5/5 pass** (`test/linkStore.test.js`), exit 0. The `node --test`
  glob expands correctly on this repo's Node v24.
- `vite.config.ts` exclude scopes to root `test/**` only; vitest still discovers
  `src/**` specs (5 ran), so no regression to existing suites.

## Security / operational risk
None. Pure in-memory data structure, no I/O, no eval, no external input sink,
no injection surface. O(n) linear dedup scan is fine at this scale.

## Non-blocking notes
- `LinkStore` is standalone and not yet wired into the app (the UI reads links
  via the `/api/links` backend in `src/api/links.ts`). This is fine as an
  isolated, tested deliverable for issue #13, but the dedup guarantee is not yet
  enforced on the live storage path.
- The diff carries recompiled `__pycache__/*.pyc` bytecode changes with no Python
  source change. Committed bytecode is a pre-existing repo-hygiene issue, not
  introduced meaningfully here; not blocking.

Change is correct, safe, and its tests pass. Approving.
