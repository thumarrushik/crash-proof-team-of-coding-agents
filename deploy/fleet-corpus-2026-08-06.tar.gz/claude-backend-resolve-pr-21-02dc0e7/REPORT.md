# PR #21 conflict resolution — `claude/issue-5` ← `main`

## Summary

Merged `origin/main` into `claude/issue-5`. Four files carried conflicts:
`links.py`, `README.md`, `REPORT.md` (textual), and `tests_regression.py`
(a semantic conflict the textual merge could not see). Every conflict was
resolved keeping **both** sides' intent — neither side was clobbered. All
backend test suites pass (66/66).

The two branches evolved the same store module (`links.py`) along
complementary axes:

- **This branch (`claude/issue-5`)** — a canonical, version-independent
  timestamp: `add_link(url, title, created_at=None)` stamps a **unix epoch
  integer** `created_at`; the HTTP layer (`app.py`) serializes it per API
  version (`/v0` raw epoch, `/v1` ISO 8601).
- **`main`** — click tracking: a stable `id`, a `clicks` counter, a
  `visit(link_id)` function, the `visit` CLI verb, a shared `_write_all`
  write choke point, and the `migrations.py` backfill.

These are orthogonal, so the merged record is the union of both intents:
`{"id", "url", "title", "created_at", "clicks"}` with `created_at` as an epoch
integer. This is exactly the shape the already-clean `tests_backend.py`,
`tests_contracts.py`, and `app.py` depend on.

## Conflicts and resolutions

### `links.py` (content) — kept both feature sets
- Imports: kept the branch's `time` (for the `created_at` default) **and**
  `main`'s `uuid` (for `id`). Dropped `datetime/timezone` — they were only for
  `main`'s `added_at` ISO string, which is superseded by the branch's canonical
  epoch `created_at` (ISO serialization now lives in `app.py`).
- Kept `main`'s `_write_all` choke point and its `visit()` / `LinkNotFound`.
- `add_link` keeps the branch's `created_at=None` parameter **and** `main`'s
  `id` + `clicks: 0`. The record is the merged union of keys.
- CLI `list` line prints both `created_at` and the clicks column; the `visit`
  subcommand from `main` is kept intact.

### `tests_regression.py` (semantic, no text conflict) — realigned to merged shape
`main`'s two exact-keys assertions pinned `{id, url, title, added_at, clicks}`.
Realigned both to the merged canonical shape
`{id, url, title, created_at, clicks}`. The intent — "records carry exactly the
expected keys, and a timestamp is recorded" — is fully preserved; only the
timestamp field name/type was reconciled to the shipped design.

### `README.md` (content) — hand-merged, both sides kept
- "Links store" note now documents the full merged record and both the epoch
  `created_at` and the `clicks` counter.
- Usage example prints both `created_at` and `clicks`.
- Kept `main`'s added "**Test**" section listing the backend / migrations /
  markdown suites.

### `REPORT.md` (add/add) — replaced with this report.

## Tests

```
python3 tests_backend.py     -> 17/17 passed  (exit 0)
python3 tests_contracts.py   ->  7/7 passed   (exit 0)
python3 tests_markdown.py    ->  4/4 passed   (exit 0)
python3 tests_regression.py  -> 30/30 passed  (exit 0)
python3 tests_migrations.py  ->  8/8 passed   (exit 0)
```

Total: **66/66 passing.** No conflict markers remain in the tree.

**tests_passed: true**
