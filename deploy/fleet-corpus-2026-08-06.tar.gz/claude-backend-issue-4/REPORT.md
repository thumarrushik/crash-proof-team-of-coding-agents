# Task Report

## What was built
Tagging for the linkbox link store (issue #4), served over HTTP. The pure logic
layer (`links.py`) gained optional tag support: `add_link(url, title, tags=None)`
normalizes tags (strip + lowercase, drop blanks, dedupe preserving first-seen
order) and enforces a cap of 10 distinct tags, raising `TooManyTagsError` on the
11th; `list_links(tag=None)` filters case-insensitively by a single tag. A thin
stdlib HTTP transport (`server.py`) exposes the versioned contract: `POST
/v0/links` accepts an **optional** `tags: [string]` field (additive — clients
that omit it keep working) and `GET /v0/links?tag=<t>` filters by tag, both
returning the canonical `{data: ...}` envelope. Failures return `{error: {code,
message, field, component}}`: bad input (blank url/title, malformed JSON,
non-list / non-string tags) is `422 ERR_SCHEMA_VALIDATION`, and exceeding the cap
is `422 ERR_TOO_MANY_TAGS` — a stable, dedicated machine code clients branch on.
Per the api-contracts skill this is a purely **additive** change, so it stays on
`/v0` with no version bump. Old records without a `tags` key are served as
`tags: []`, so both deploy orders (old code on new data, new code on old data)
survive without a migration.

## How it was verified
- `python3 tests_contract.py` → **9/9 passed**. Contract tests over **real
  HTTP**: each boots `server.py` as a subprocess on an OS-assigned port with a
  throwaway store and asserts the envelope field-by-field — happy path (POST
  with/without tags, lowercasing + dedup, `GET` newest-first, `?tag=` filter,
  exactly 10 tags) and failure paths (11th tag → `422 ERR_TOO_MANY_TAGS`; blank
  title, non-list tags, malformed JSON → `422 ERR_SCHEMA_VALIDATION`).
- `python3 tests_backend.py` → **12/12 passed**: the 6 pre-existing links-store
  unit tests (confirming the additive change broke nothing) plus 6 new tag tests
  added here (default-empty tags, normalize/dedupe, case-insensitive filter,
  10-allowed/11-rejected cap, non-list/non-string rejection, legacy-record
  backfill).
- Stability: ran `python3 tests_contract.py` 5× consecutively — 9/9 every run.
- Live drive: booted `server.py` and drove it with `curl`, observing firsthand a
  legacy no-tags POST (`tags: []`), mixed-case dedup normalization
  (`["Python","python","  WEB  ","News"]` → `["python","web","news"]`), the
  `?tag=PYTHON` case-insensitive filter, and the `422 ERR_TOO_MANY_TAGS`
  envelope on an 11-tag POST.

## Files
- `links.py` — added tag normalization (`normalize_tags`), the `MAX_TAGS` cap,
  domain exceptions (`LinkError` / `InvalidInput` / `TooManyTagsError` carrying
  stable `code`s), the optional `tags` param on `add_link`, tag filtering in
  `list_links`, backward-compatible `tags: []` for legacy records, and CLI tag
  support. (Base store logic originates from issue #1; carried into this branch.)
- `server.py` — new stdlib HTTP transport: `POST /v0/links`, `GET
  /v0/links?tag=`, the canonical envelope, 422 mapping by exception `code`, and a
  last-resort 500-envelope guard that logs loud instead of swallowing.
- `tests_backend.py` — added 6 store-level tag tests (see above).
- `tests_contract.py` — contract tests exercising the API over real HTTP (seeded
  spec for this issue).
- `.gitignore` — base file from the links store (issue #1), included so this
  branch builds and tests standalone.

## Residual risk
- The store is a single JSON file read fully into memory (pre-existing issue-#1
  design); `list_links` / tag filtering is O(n) and unpaginated. Fine for a tiny
  store, but the list endpoint would need pagination at large scale — out of
  scope for this additive tagging change.
