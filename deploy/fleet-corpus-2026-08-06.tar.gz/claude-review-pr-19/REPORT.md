# Review — PR #19: Design: link-preview fetcher service (issue #12)

**Verdict: APPROVE.** `tests_passed = true`.

The change is a design/documentation deliverable: two ADRs and one blueprint.
It is internally consistent, its capacity arithmetic checks out, its
cross-document links resolve, and it degrades no existing system health — it
adds structure where there was none. No blocking findings.

## Scope of the change

`git diff main...HEAD --stat`:

```
 docs/adr/0001-async-queue-for-preview-fetch.md     |  73 ++++
 docs/adr/0002-http-enqueue-command-over-event-broker.md | 63 ++++
 docs/blueprint/link-preview.md                     | 366 +++++++++++++++++++++
 3 files changed, 502 insertions(+)
```

All three files are new; nothing is modified or deleted. The repository
contains only Markdown docs (README + these) — no code, build manifest, or
callers exist. Every added line was read.

## Tests

**Not applicable — no test harness exists.** Verified by discovery:

```
$ make -n test        → no Makefile test target
$ ls package.json ...  → no build manifests
$ find . -type f (code/build/test, excluding .claude/)  → (none)
```

The repo is docs-only; there is no code to compile or suite to run. `tests_passed`
is therefore set on the basis of the design review (correct, safe, internally
consistent), not on a green suite — there is no suite to be green. This is
disclosed rather than inferred, per verdict-discipline.

## What I checked (design review)

**Internal consistency — ADR ↔ ADR ↔ blueprint.** ADR-0001 (async queue, not
sync-on-save) and ADR-0002 (HTTP enqueue, not broker) cross-reference each
other and the blueprint cites both. The `pending`-rows-are-the-queue decision,
the idempotency-key story, single-writer leasing, and the exhaustive
`status`/`reason` enums are stated consistently across §3, §4, and §5 of the
blueprint. The one-writer-per-fact table (§3) is coherent and the rejected
"preview columns on the Link row" alternative is correctly derived from it.

**Capacity arithmetic (§6) — recomputed, all correct.**
- 5,000 users × 20 saves/day = 100,000 saves/day; /86,400 ≈ 1.16/s; ×10 peak ≈ 12/s. ✓
- Little's law: 12/s × 2 s = 24 in-flight (p95); × 10 s = 120 (all-slow). ✓
- Drain: 32 slots × (1 / 0.5 s) ≈ 64 fetches/s > 12/s peak. ✓
- Bulk import 10,000 / 64 ≈ 156 s ≈ 2.6 min. ✓
- Storage 100,000/day × 1 KB = 100 MB/day ≈ 36 GB/yr; 1 M rows ≈ 1 GB. ✓
- Reads 5,000 × 10 / 86,400 ≈ 0.6/s avg. ✓  Growth 2× → ~24/s peak, still < 64/s. ✓
The 32-slot provisioning (>24 p95 concurrency, headroom) is consistent with the
stated all-slow worst case being handled by queue depth, not slot count — the
doc says exactly this and does not overclaim.

**Cross-document links resolve.** Both `../adr/0001-...md` and `../adr/0002-...md`
referenced in the blueprint exist under `docs/adr/`.

**Failure/security coverage (§5).** Every dependency (remote origin, own
Postgres, inbound trigger, worker crash) maps down/slow/wrong to a contracted
terminal state; SSRF guard refuses private/loopback/link-local targets before
connect; no path is "handle gracefully" or silently wrong. Fail-loud and
one-writer rules are honored throughout.

**Missing-hunk / forensics.** `CONTRACT.md` is explicitly delegated to
downstream and named as such — its absence here is intended, not an omission.
No secrets, no injection surface (docs only). Residual unknowns are named in §8
with trigger conditions rather than hidden.

## Non-blocking findings (author's call — none blocks merge)

- `suggestion (non-blocking)` — docs/adr/0002-http-enqueue-command-over-event-broker.md,
  "Decision" paragraph: the enqueue payload is written as `{link_id, url}` and
  idempotency as `(tenant, link_id, url)`, while blueprint §4 (contract #1) adds
  a `version` field and an ordering guard. Not a contradiction — the blueprint
  is the decision-complete artifact and legitimately refines the ADR — but a
  one-line mention of `version` in ADR-0002 would keep the two from drifting for
  a reader who lands on the ADR first.
- `suggestion (non-blocking)` — docs/blueprint/link-preview.md §5 (Dependency A,
  `blocked_target`): the SSRF guard "resolve + check before connect" has a
  DNS-rebinding TOCTOU window; the downstream implementation should pin/reuse
  the resolved IP for the actual connect. A design-level note for the backend
  lane, not a defect in the doc.
- `question (non-blocking)` — docs/blueprint/link-preview.md §3: the idempotency
  key includes `url` (same-url re-enqueue = no-op) while the ordering guard keys
  on `version`. The interaction when a URL reverts to a prior value carrying a
  *higher* version is slightly underspecified; worth a sentence when CONTRACT.md
  is written.

## Verdict

The blueprint answers issue #12's central question (single-writer ownership of
preview facts) explicitly and correctly, backs its two load-bearing decisions
with ADRs, and is decision-complete enough for backend/frontend/testing to
start. It improves the system's design health and introduces no risk. Approving.
