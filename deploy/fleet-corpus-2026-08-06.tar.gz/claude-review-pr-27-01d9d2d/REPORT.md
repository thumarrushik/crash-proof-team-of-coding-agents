# Review — PR #27 (issue #13: Improve duplicate link handling)

**Verdict: BLOCK — do not merge (`tests_passed=false`).**

The PR's own unit suite is green, but the change cannot be safely merged into
`main`: it does not integrate with the real application, it conflicts on
`package.json`, and either resolution of that conflict is harmful. It also does
not actually improve duplicate handling anywhere the app uses.

---

## Blocking findings (must fix to merge)

### 1. `issue (blocking): package.json:1-9 — add/add merge conflict; either resolution is harmful
The branch was cut from the seed commit `9360ca4` (README only). `main` has
since become a real Vite/React + Python app. This PR re-creates `package.json`
from scratch, so merging into `main` fails:

```
$ git merge --no-commit --no-ff main
Auto-merging package.json
CONFLICT (add/add): Merge conflict in package.json
Automatic merge failed; fix conflicts and then commit the result.
```

Neither resolution is acceptable:
- **PR side wins** → the application manifest is destroyed. The PR's
  `package.json` drops `"type": "module"`, every dependency
  (`react`, `react-dom`, `@tanstack/react-query`, `vite`, `vitest`, …) and every
  script (`dev`, `build`, `preview`, `typecheck`, `test: vitest run`), replacing
  the whole thing with `{ "test": "node --test" }`. `src/App.tsx`,
  `vite.config.ts`, etc. no longer build or run.
- **main side wins** → the PR contributes only the orphan module below and its
  `node --test` script is lost, so `npm test` (now `vitest run`) never exercises
  `test/linkStore.test.js`. The PR becomes a no-op plus dead code.

### 2. `issue (blocking): src/linkStore.js:1-32 — orphan module; does not integrate with the system
Design is the first bar (pr-review: "does it integrate with the system or fight
it?"). `LinkStore` is imported by nothing except its own test:

```
$ grep -rn "linkStore" .            # (excluding .git)
./test/linkStore.test.js:5: const { LinkStore } = require('../src/linkStore');
```

The real link store on `main` is `links.py` (JSON-backed, Python) and
`src/api/links.ts` (TS API client). This CommonJS class is a parallel toy store
in a third module system that no app code calls. It is dead code on arrival.

### 3. `issue (blocking): the PR does not address issue #13 in the real codebase
Issue #13 is "Improve duplicate link handling." The store the app actually uses,
`main:links.py` `add_link`, still unconditionally appends and has **no** dedup
logic (verified: no `find`/`exists`/`already` guard around the append). This PR
adds dedup only to the orphan `LinkStore`, so the app's real duplicate behavior
is unchanged. The stated goal is not met where it matters.

---

## The isolated code, on its own terms

Reviewed in isolation, `src/linkStore.js` is clean and correct: `save()`
trim-normalizes, rejects non-string/empty input with `TypeError`, returns the
existing row on a duplicate; `all()` returns a defensive copy. The tests are
behavioral and cover the duplicate, whitespace, distinct-URL, and invalid-input
branches. None of this is the problem — the problem is that it is the wrong
artifact merged the wrong way.

Non-blocking, were this ever integrated:
- `suggestion: save()` dedup is O(n) linear scan; fine at toy scale, but the
  real store is file-backed and this class does not persist, so it could not
  replace `links.py` as written.

---

## Evidence

**PR unit suite (green, run as the last workspace action):**
```
$ node --test
ℹ tests 5   ℹ pass 5   ℹ fail 0   ℹ skipped 0
```

**Merge check (reconfirmed after restoring the tree):**
```
$ git merge --no-commit --no-ff main
CONFLICT (add/add): Merge conflict in package.json
```

`main`'s own test suites (`vitest`, `pytest`) were **not verified** — they are
irrelevant to this branch, which cannot cleanly reach `main`'s tree.

## Why `tests_passed=false`

The PR's five unit tests pass, but "tests pass" is not the merge bar. The change
is unsafe to merge (conflict + manifest clobber), does not integrate (orphan
module), and does not accomplish issue #13 in the code the app runs. Per the
review-lane bar, a change that degrades system code health is not accepted even
when its own tests are green. The blocking fix is to rebase onto current `main`
and implement duplicate handling in `links.py` / `src/api/links.ts` rather than
introduce a disconnected `package.json` and `src/linkStore.js`.
