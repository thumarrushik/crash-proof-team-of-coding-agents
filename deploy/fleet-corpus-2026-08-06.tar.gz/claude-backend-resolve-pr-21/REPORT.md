# PR #21 conflict resolution — `claude/issue-5` ← `main`

## Summary

Merged `origin/main` into `claude/issue-5` and resolved three conflicts. Both
branches independently added timestamp handling to the links store; they were
reconciled onto the branch's versioned-API design, which is a strict superset of
`main`'s intent. All test suites pass.

## Conflicts and how each was resolved

### `links.py` (add/add) — resolved to branch design (`created_at` epoch)
- **`main`'s intent:** record when a link was added, stored as an ISO 8601
  string field `added_at`.
- **branch's intent:** store a canonical, version-independent **unix epoch
  integer** `created_at`; let the HTTP layer (`app.py`) serialize it per API
  version — `/v0` serves the raw epoch, `/v1` serves ISO 8601.
- **Resolution:** kept the branch's `created_at` epoch design. It is not a
  clobber of `main`: `main`'s "record an ISO 8601 timestamp" requirement is
  fully satisfied by `/v1/links`, while the canonical storage stays a stable
  integer. Keeping `main`'s `added_at` field would have broken the un-conflicted
  `app.py` and `tests_contracts.py`, which both depend on `created_at`.

### `tests_backend.py` (add/add) — resolved to branch tests
- Kept the branch's tests, which are a superset: they assert `created_at` is a
  unix epoch integer (`main`'s `added_at`-presence check is subsumed by these
  stronger assertions and would have failed against the chosen storage shape).

### `README.md` (content) — hand-merged, kept BOTH sides
- Kept the branch's richer "Links store", "HTTP API" (versioned routes +
  RFC 8594 deprecation), and "Tests" sections.
- **Preserved `main`'s unique contribution:** its "Development / Install"
  content (clone, no dependencies, Python 3.8+) was folded in as a new
  `## Development` section rather than dropped.

## Files brought in cleanly from `main` (no conflict)
`markdown_export.py`, `tests_markdown.py`, and the `docs/adr` + `docs/blueprint`
files merged automatically. Verified `markdown_export` depends only on
`title`/`url`, so it is unaffected by the timestamp-field decision.

## Tests

```
python3 tests_backend.py     -> 8/8 passed   (exit 0)
python3 tests_contracts.py   -> 7/7 passed   (exit 0)
python3 tests_markdown.py    -> 4/4 passed   (exit 0)
```

Total: **19/19 passing.** (The traceback printed during `tests_contracts.py` is
the expected fail-loud output of `test_corrupt_store_fails_loud_...`, which
deliberately corrupts the store to assert the 500 envelope path; the test
passes.)
