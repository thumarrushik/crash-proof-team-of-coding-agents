# Task Report

## What was built

Issue #11 reported a flaky "recently added" test that fails when the suite runs
within a second of midnight and passes on rerun. Diagnosed to a **named cause in
the Time category**: an *unsynchronized wall-clock read across the midnight
boundary*. The link's `added_at` was stamped from one read of the system clock,
and "today" was computed from a *second, independent* read; when those two reads
straddle midnight (stamp at 23:59:59 on day D, "today" at 00:00:00 on day D+1),
the just-added link is no longer "from today" and the assertion fails.

The fix is a **controlled clock via dependency injection**, not a widened window
or a retry (both explicitly rejected). `linkbox/recency.py` makes the current
instant an injected value: `recently_added(links, now)` never reads the wall
clock itself, and `LinkStore` owns a single clock threaded through both stamping
and querying. Same-day recency semantics are unchanged. Tests pin `now` to fixed
instants and are deterministic by construction. `tests/test_recency.py` contains
a conviction test that reproduces the midnight failure deterministically (a
stepping clock, no real waiting), the fixed-behavior counterpart, boundary and
behavior coverage, and an in-suite 10x determinism battery. `tests/run_battery.sh`
is the external 10x rerun battery (optionally pinning the real clock to
`23:59:59` via libfaketime when present).

## How it was verified

- `pytest -q` — **16 passed** (final full-suite run, the authoritative result).
- `bash tests/run_battery.sh` — **BATTERY GREEN: 10/10 runs passed** (the 10x
  rerun battery pinned to the midnight boundary).
- Reversed-collection-order run of the suite — **16 passed** (proves test
  independence / no shared-state leakage).
- Mutation audit — every one of the 16 tests was observed red at least once:
  Mutant A (ignore the injected clock, read ambient time) → 4 red incl. the
  conviction test; Mutant B (flip the day comparison `==`→`!=`) → 15 red;
  Mutant C (reverse insertion order) → the 2 order tests red; Mutant D (return
  `None` when empty) → the empty-input test red. All mutants were reverted and
  the suite confirmed green.

## Files

- `linkbox/__init__.py` — package exports (created)
- `linkbox/recency.py` — recency code under test with an injected clock, the fix (created)
- `tests/test_recency.py` — black-box conviction + behavior + boundary + 10x battery tests (created)
- `tests/run_battery.sh` — external 10x rerun battery, midnight-pinned (created)
- `pyproject.toml` — pytest config (`pythonpath`, `testpaths`) (created)
- `REPORT.md` — this report (created)

## Note on process

The team mandate names `TodoWrite` for the six-phase task list; this worker only
exposes the `TaskCreate`/`TaskUpdate` task tools (no `TodoWrite`), so the phase
list (Understand, Plan, Author, Run, Self-review, Report) was created and driven
with those. Recorded here per the mandate's "note any assumption in REPORT.md."
