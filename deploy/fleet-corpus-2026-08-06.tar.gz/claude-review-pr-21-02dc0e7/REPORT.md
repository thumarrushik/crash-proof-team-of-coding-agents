# Review — PR #21: API dates must be ISO 8601 (breaking change) — issue #5

**Verdict: APPROVE (tests_passed = true).** The change is well-designed, safe,
and its tests are behavioral and green. No blocking findings.

## What the PR does

- `links.py`: storage timestamp becomes a **canonical unix-epoch integer**
  `created_at` (was `added_at`, an ISO string). `add_link` gains an optional
  `created_at` param (defaults to `int(time.time())`); CLI `list` updated.
- `app.py` (new): stdlib `http.server` API serving `GET /v0/links` (epoch int,
  **deprecated**) and `GET /v1/links` (ISO 8601 UTC string) **side by side**,
  under a `{"data": ...}` / `{"error": {...}}` envelope. `/v0` carries RFC 8594
  `Deprecation`/`Sunset`/`Link` headers.
- `tests_backend.py`: adds epoch-integer assertions. `tests_contracts.py` (new):
  pins both served shapes and the deprecation headers over **real HTTP**.
- `README.md`: documents the versioned routes and deprecation policy.

The design is the correct answer to a breaking type change: rather than mutate
`/v0` in place, a new `/v1` is served beside it with a deprecation runway. This
improves system code health. Approved on Google's "definitely improves" bar.

## Verification (evidence)

Final run, performed after all other workspace actions:

```
python3 tests_backend.py     -> 8/8 passed   (exit 0)
python3 tests_contracts.py   -> 7/7 passed   (exit 0)
python3 tests_markdown.py    -> 4/4 passed   (exit 0)
```

The traceback printed mid-run of `tests_contracts.py` is expected output of
`test_corrupt_store_fails_loud_with_envelope_not_bare_500`, which deliberately
corrupts the store to assert the 500-envelope path; the test passes.

Forensics: grepped all callers of `add_link`/`list_links` and the field name —
no `added_at` reference survives in code (only in the committed notes). The
merged-in `markdown_export.py` depends only on `title`/`url`, so it is
unaffected by the timestamp reshape. Merge is clean (`git diff --check` finds no
conflict markers). Contract tests exercise the delta over real HTTP — they fail
if a served field's type changes, so the behavior delta is genuinely tested.

## Non-blocking findings

- **suggestion (non-blocking): app.py:135 — 404 uses `ERR_MISSING_FIELD` with
  `field="path"`.** A route-not-found is not really a missing *field*; a code
  like `ERR_NOT_FOUND` would read more truthfully. The contract test pins the
  current code, so this is intentional and consistent — author's call.
- **suggestion (non-blocking): app.py — only `do_GET` is handled.** A `POST`/
  other method falls through to `BaseHTTPRequestHandler`'s default 501 HTML
  page, bypassing the canonical error envelope. Out of scope for a GET-only
  read API, but worth a follow-up if write routes land.
- **nitpick (non-blocking): no migration for pre-existing `added_at` records.**
  If a `links.json` written by the old code existed, `serialize_v*` would
  `KeyError` on `created_at` and surface as a loud 500 (not silent). Greenfield
  store, so no real data is at risk — noted for completeness.
- **nitpick (non-blocking):** the PR commits a `REPORT.md` of merge-conflict
  notes into the repo root (now replaced by this review). Harmless, but such
  process notes usually belong in the PR description, not the tree.

None of these block merge.
