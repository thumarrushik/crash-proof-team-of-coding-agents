# Review — PR #18: Export: markdown list of saved links (issue #2)

**Verdict: APPROVE** (tests_passed=true)

## What the PR does
Adds a `export_markdown()` public function to `links.py` that renders saved
links as a newest-first Markdown bullet list (`- [title](url)`), plus a matching
`export` CLI subcommand, README docs, and two unit tests.

## Diff scope
- `links.py` (+13): new `export_markdown()`, docstring API note, `export` CLI
  branch, and updated usage text.
- `tests_backend.py` (+17): `test_export_markdown_empty_store`,
  `test_export_markdown_lists_newest_first`, registered in `_run()`.
- `README.md` (+12): usage example.

## Verification
- `python3 tests_backend.py` → **8/8 passed, exit 0**.
- CLI exercised end-to-end:
  - `export` on empty store → empty output, exit 0.
  - `export` after two adds → newest-first bullets, matching the README example
    byte-for-byte.
  - unknown subcommand → usage text incl. new `export` line, exit 2.

## Correctness / safety
- `export_markdown()` reuses `list_links()`, so ordering (newest-first) and the
  empty-store case are correct and consistent with existing behavior.
- Keys `title`/`url` are always populated by `add_link`, so the f-string
  formatting cannot `KeyError`.
- No new I/O, no shell/eval, no external input paths; stdlib-only, matching the
  module's design.

## Non-blocking notes
- Markdown special characters in a title (`]`, `)`) are not escaped, so an
  exotic title could render imperfectly. This is cosmetic, out of scope for the
  issue, and consistent with the rest of the minimal codebase — not a blocker.

The change is correct, safe, minimal, and well-tested. Approving.
