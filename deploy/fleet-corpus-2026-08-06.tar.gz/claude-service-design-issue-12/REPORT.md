# Task Report

## What was built

A decision-complete design for the **`link-preview` fetcher service** (linkbox
issue #12), so backend, frontend, and testing can start without asking the
author anything.

- **Blueprint** — `docs/blueprint/link-preview.md`: bounded-context boundary
  (the word "link" means two things → two contexts); **one writer per fact**
  (link-preview is the sole writer of `title`/`description`/`image_url`/
  `status`; the links store never writes preview columns and link-preview never
  reads its tables — the URL arrives inside the enqueue command); owned data
  model with an exhaustive `status`/`reason` state machine; a versioned,
  tenant-scoped contract surface (enqueue, single + batch read, refresh,
  migrate); **per-dependency failure modes — down/slow/wrong — each with a
  contracted response** for the remote origin, the datastore, and the inbound
  trigger, plus worker-crash/concurrency/poison-URL and out-of-order-enqueue
  edges; and **capacity arithmetic** (100k saves/day → ~12 fetches/s peak →
  32-slot worker pool, bulk-import drain 2.6 min, ~37 GB/yr, first bottleneck =
  fetch concurrency, watched by oldest-pending-age + queue-depth).
- **ADRs** — `docs/adr/0001-async-queue-for-preview-fetch.md` records the
  issue's core decision (**async queue over sync-fetch-on-save**) with
  alternatives and consequences; `docs/adr/0002-http-enqueue-command-over-event-broker.md`
  records the trigger transport (HTTP enqueue over a broker). The blueprint
  cites both by number at each decision point.

During self-review I closed one gap the first draft missed: replayed/out-of-order
enqueue now has a contracted response (a monotonic `version` ordering guard, so
a stale URL can never overwrite a newer one).

## How it was verified

- **Cross-document link integrity** — a shell check resolved every `../adr/...`
  link in the blueprint: both ADR targets exist (`-> all links resolve`).
- **Capacity arithmetic** — recomputed every figure in §6 independently with
  `python3`; all matched the doc (avg 1.16/s, peak 11.57/s, Little's-law 23/116
  concurrent, drain 64/s, bulk 156 s, 102 MB/day ≈ 37 GB/yr, reads 0.58/s,
  2× growth still under one worker).
- **[[self-review]] passes** — grep for banned phrases (`TBD`, "will be defined
  during implementation", "handle errors gracefully", "should scale", …) found
  only the sentence explicitly asserting the opposite; every `reason` enum value
  (6) appears both in its definition and in a contracted failure response — no
  orphan states; downstream dry-run for backend/frontend/testing found no
  unanswered question.
- **[[lean-service]] standard** — the design asserts `/v0` versioning, tenant
  isolation by construction, migrations via a migrate endpoint, the two-layer
  split with the canonical fail-loud envelope, cross-service over HTTP only, and
  no shared datastore.

No application code was produced (this is a design task); the "tests" are the
design-artifact checks above, which passed.

## Files

- `docs/blueprint/link-preview.md` — created (the service blueprint)
- `docs/adr/0001-async-queue-for-preview-fetch.md` — present, cited (sync vs async decision)
- `docs/adr/0002-http-enqueue-command-over-event-broker.md` — present, cited (trigger transport)
- `REPORT.md` — created (this report)
