# Review — PR #23: Optimistic add-link with rollback (closes #9)

**Lane:** review · **Head:** `claude/issue-9` · **Base:** `main`
**Verdict:** ✅ Approve — correct, safe, tests pass.

## Scope

Adds a React + TanStack Query linkbox frontend implementing optimistic
add-link with rollback:

- `src/api.ts` — typed server boundary (`listLinks`, `addLink`, `ApiError`).
- `src/useLinks.ts` — `useLinks` query + `useAddLink` optimistic mutation.
- `src/LinkBox.tsx` — form + list UI with saving/error/empty states.
- `src/LinkBox.test.tsx` — 7 tests over render + both mutation branches.
- Supporting scaffold: `App.tsx`, `main.tsx`, MSW test harness, styles, Vite/TS config.

## Verification (this run)

- `npm run typecheck` (tsc --noEmit): **clean**
- `npm test` (vitest): **7 passed** (`src/LinkBox.test.tsx`)
- `npm run build` (tsc -b && vite build): **succeeds**, 81 modules
- No conflict markers remain in the tree.

## Correctness review

The optimistic mutation follows the canonical React Query contract correctly:

- **onMutate** cancels in-flight refetches (so a late GET can't clobber the
  optimistic write), snapshots `previous`, and prepends a temporary entry keyed
  `optimistic-<uuid>`. (`useLinks.ts:42-63`)
- **onError** restores the exact snapshot; the failure is surfaced via
  `isError`/`error` and the form inputs are intentionally preserved for retry.
  (`useLinks.ts:64-69`, `LinkBox.tsx:39-51,101-106`)
- **onSettled** invalidates to re-sync from server truth on both branches.
  (`useLinks.ts:70-73`)
- Draft is cleared only in the mutation's `onSuccess`, so a failed add keeps the
  user's work. (`LinkBox.tsx:42-49`)

Tests exercise both the success reconcile (optimistic row → server-keyed row,
saving badge clears) and the failure rollback (row removed, empty state
restored, error surfaced, inputs preserved), plus the empty-field guard that
fires no request. This is the heart of the feature and it is well covered.

## Non-blocking notes

- **`javascript:` URLs in `href`** (`LinkBox.tsx:9`): the URL field is
  `type="url"` but `noValidate` is set and validation only checks non-empty, so
  a user could store a `javascript:` link that executes on click. It is the
  user's own personal collection (self-only), so severity is low, but a scheme
  allowlist (`http(s)` only) would harden it.
- **Post-success GET failure**: a successful add relies on the onSettled refetch
  to show server truth; if that refetch errors, the just-added (persisted) link
  drops from view behind the list error state. Transient and acceptable.
- Concurrent adds are prevented by disabling the submit button while pending, so
  the per-mutation snapshot rollback can't clobber a sibling optimistic entry.

None of these block merge.
