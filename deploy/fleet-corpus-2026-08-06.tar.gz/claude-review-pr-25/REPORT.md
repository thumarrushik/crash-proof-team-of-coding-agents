# Review — PR #25: Regression suite for the links store (issue #10)

**Verdict: APPROVE.** The change is correct, safe, and its tests pass. No
blocking findings.

## Scope reviewed

`git diff main...HEAD --stat` — every file below was read in full:

| File | Lines | Reviewed |
|------|-------|----------|
| `.gitignore` | +3 | ✅ |
| `links.py` | +82 | ✅ |
| `tests_backend.py` | +119 | ✅ |
| `tests_regression.py` | +460 | ✅ |

## What I ran

```
python3 tests_backend.py      → 6/6 passed,  exit 0
python3 tests_regression.py   → 30/30 passed, exit 0
```

Both runs are in the transcript; the regression run is the final workspace
action backing the verdict.

## Assessment

**Design.** A stdlib-only JSON-backed link store plus a comprehensive regression
suite. The suite drives only the public API (`add_link`/`list_links`) and the
documented on-disk JSON handoff — black-box, behavior-oriented, so refactors that
preserve behavior stay green. Tests point `links.LINKS_FILE` at throwaway temp
files, keeping them independent and order-free. Temp files are cleaned up in a
`finally`.

**Functionality.** Coverage is thorough and hits the edges the bar demands:
input rejection (empty/whitespace/non-string url & title), "rejected add leaves
store untouched / does not create file", corrupt & malformed backing file
(fail-loud, no clobber), unicode round-trip (API + raw disk), huge inputs,
newest-first ordering, copy-safety of the returned list, and process-restart
persistence.

**Honest characterization tests.** Two behaviors the store does *not* guarantee
are pinned as characterization tests, not asserted as features:
`test_duplicate_url_is_stored_not_deduped` and
`test_concurrent_add_from_stale_snapshot_loses_the_interleaved_write`. The latter
reproduces the unlocked read-modify-write last-writer-wins race deterministically
(no threads/sleeps). Both are clearly labeled as pinning current behavior so a
future fix is a conscious change — good practice.

**Correctness spot-checks.** Verified the assertions actually bind:
`added_at` UTC/ISO-8601 check parses via `datetime.fromisoformat` and compares
offset to `timezone.utc`; the fresh-copy test works because `_read_all` re-reads
disk each call; unicode survives despite `json.dump`'s default `ensure_ascii`
because the read side decodes the escapes. Runner exit-code logic
(`sys.exit(1 if _run() else 0)`, `_run` returns failure count) is correct.

## Non-blocking notes

- `suggestion (non-blocking):` The suite header (`tests_regression.py:1`) frames
  `links.py` as pre-existing "from issue #1", but in this diff `links.py` is a
  new file. The framing is cosmetic and does not affect correctness — the store
  and its tests are delivered together and consistent.
- `nitpick (non-blocking):` `links.py` uses an unlocked read-modify-write with
  no atomic replace (`os.replace`); a crash mid-write could truncate the store.
  Out of scope for a test-suite PR and already characterized by the concurrency
  test — noted for a future hardening change, not a blocker.

No findings rise to blocking. Approving.
