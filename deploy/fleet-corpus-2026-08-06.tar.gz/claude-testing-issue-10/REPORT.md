# Task Report

## What was built

A black-box regression suite for the links store (`links.py`, from issue #1),
added as `tests_regression.py` — 30 tests that turn each of the store's promises
and every failure branch into an executable spec. The suite is organized by
promise, and the names read as the contract:

- **add** — returns a record with exactly `{url, title, added_at}`; stamps
  `added_at` as UTC ISO-8601; strips surrounding whitespace; persists
  oldest-first. Failure branches: rejects empty / whitespace-only / non-string
  url and title with `ValueError`, and a rejected add leaves the store untouched
  (no file created, no partial append).
- **list** — newest-first ordering; empty on missing file and on an empty array;
  returns a fresh copy that is safe to mutate.
- **dedupe** — *characterized, not assumed.* The shipped store does **not**
  dedupe; duplicate URLs are stored as distinct records. Tests pin that actual
  behavior so any future dedupe change is a deliberate, reviewed decision. (See
  spec-gap note below.)
- **export handoff** — the on-disk JSON is a list of records with exactly the
  three documented keys, round-trips byte-for-byte through an independent reader,
  and survives a simulated process restart.
- **corrupt store** failure branches — non-list JSON fails loud with a "corrupt"
  `ValueError`; malformed JSON fails loud; a failed add never overwrites a
  corrupt file.
- **edge-case taxonomy** — empty title (rejected); duplicate URL (kept); unicode
  titles and URLs (round-trip intact through JSON encode/decode); huge (100k-char)
  URL and title (stored whole, no truncation); concurrent adds — a deterministic
  reproduction (no threads, no sleeps) of the store's unlocked read-modify-write
  losing an interleaved write (last-writer-wins).

Each test drives only the public API (`add_link` / `list_links`) and the
documented on-disk file, asserts observable outputs, and points `LINKS_FILE` at a
throwaway temp file so tests are independent and re-runnable in any order.

**Spec gap noted (not fixed — out of lane):** issue #10 lists *dedupe* as a store
promise, but `links.py` has no dedupe and no dedicated export function. This suite
characterizes the true behavior rather than inventing a contract; fixing the store
belongs to the store's own lane.

## How it was verified

- New suite: `python3 tests_regression.py` → **30/30 passed** (exit 0). Run twice
  back-to-back (repeat-independence) — 30/30 both times.
- Order-independence: ran the 30 tests in shuffled order (`random.seed(1234)`) →
  30/30 passed.
- Existing happy-path suite still green: `python3 tests_backend.py` → **6/6
  passed** (exit 0).
- **Every test seen red once.** A mutation battery (14 mutants) was applied to
  `links.py`, running the suite against each and restoring the source after —
  every one of the 30 tests is killed by at least one mutant ("(none — every test
  was killed)"). Representative mutant → tests-turned-red:
  - `drop_url_guard` → 5 red (url rejection + rejected-add-untouched + no-file)
  - `drop_title_guard` → 4 red (title rejection)
  - `no_strip` → strips-whitespace red
  - `list_not_reversed` → 4 red (newest-first, dup ordering, concurrent, copy-safety)
  - `prepend_record` → 7 red (chronological on-disk order, many-adds, ordering)
  - `drop_corrupt_guard` → non-list-JSON + append-to-corrupt red
  - `naive_timestamp` → utc-iso8601 red
  - `truncate_url` / `truncate_title` → huge-url / huge-title red
  - `dedupe_urls` → duplicate-stored + duplicate-ordering red
  - `mangle_unicode` → unicode title + url red
  - `extra_key` / `persisted_extra_key` → returns-record / roundtrip / exact-keys red
  - `cache_list` → 9 read-path tests red
  The mutation driver was scaffolding and was deleted; `links.py` is unchanged
  (empty `git diff`).

The last suite run performed after the final edit was `python3 tests_regression.py`
→ 30/30 passed.

## Files

- `tests_regression.py` (new) — the regression suite for the links store.
- `REPORT.md` (new) — this report.
