# Merge conflict resolution — PR #18 (`claude/issue-2` ← `main`)

## Summary
Merged `origin/main` into `claude/issue-2`. The only conflict was in `README.md`.
Both sides were kept — no side clobbered.

## Conflict: `README.md`
- **This branch (`claude/issue-2`, issue #2)** added documentation for the
  Markdown export feature (`links.export_markdown()` / `python3 links.py export`).
- **`main`** added a new **Development** section (Install / Run / Test).

**Resolution:** kept both. The README now documents the Markdown export usage
*and* the full Development section. The export command example was normalized to
the shipped CLI form `python3 links.py export`, and the Test section lists both
suites (`tests_backend.py` and `tests_markdown.py`).

## Non-conflicting merge content
`main` also introduced `markdown_export.py` (a `to_markdown(links)` module) and
`tests_markdown.py`, plus `docs/adr/*` and `docs/blueprint/*`. These coexist with
this branch's `links.export_markdown()` — different files/functions, no overlap.

## Verification
- `python3 tests_backend.py` → 8/8 passed (exit 0), incl. the export tests.
- `python3 tests_markdown.py` → 4/4 passed (exit 0).
- Smoke-tested the CLI: `python3 links.py export` renders `- [title](url)`
  newest-first, matching the README example.
- No conflict markers remain.

**tests_passed: true**
