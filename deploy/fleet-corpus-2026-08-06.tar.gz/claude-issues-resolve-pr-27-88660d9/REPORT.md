# Merge conflict resolution — PR #27 (`claude/issue-13` ← `main`)

## Summary
Merged `origin/main` into `claude/issue-13` to clear the merge block on PR #27.
All source code merged automatically; git surfaced a single content conflict, in
`REPORT.md` — the per-run report doc, where this branch's PR #27 write-up
collided with `main`'s stale PR #22 report. No code was clobbered on either side.

## The two intents (both preserved)
- **This branch (`claude/issue-13`, issue #13)** — improved duplicate-link
  handling in the JS store: `src/linkStore.js` treats a URL saved twice (or with
  surrounding whitespace) as the same row instead of creating a duplicate,
  covered by the `node:test` suite in `test/linkStore.test.js`.
- **`main`** — the Python link store plus click-tracking, markdown-export,
  migration, contract, and recency work (`links.py`, `migrations.py`,
  `markdown_export.py`, `server.py`, the `tests_*.py` batteries, `tests/`), and
  the React/Vite/vitest frontend (`src/`, `index.html`, config files).

Both sides land intact: the merged tree keeps `main`'s full Python + frontend
stack and this branch's `linkStore.js` deduplication. The `package.json` `test`
script runs **both** JS runners (`vitest run && node --test 'test/**/*.test.js'`)
and `vite.config.ts` excludes `test/**` from vitest so the two runners don't
collide.

## Conflict resolution
### `REPORT.md` (content conflict)
Replaced the two stale, mutually-conflicting reports with this single accurate
report for the current resolution. `server.py` and `tests_contract.py` came in
from `main` as clean adds. Nothing else in the tree conflicted.

## Verification (after the merge)
JavaScript / TypeScript (`npm ci` → deps installed, exit 0):
- `npm run typecheck` (`tsc --noEmit`) → no errors, exit 0.
- `npm test` → vitest **5/5** (`src/components/LinksPage.test.tsx`) + node:test
  **5/5** (`test/linkStore.test.js`), exit 0.

Python:
- `python3 tests_backend.py`     → **21/21**
- `python3 tests_migrations.py`  → **8/8**
- `python3 tests_markdown.py`    → **4/4**
- `python3 tests_regression.py`  → **30/30**
- `python3 tests_contract.py`    → **9/9**

**Total: 72/72 Python + 10/10 JS passing.** The pytest recency suite (`tests/`)
came in from `main` and is gated on a `pytest` install not present in this
workspace (`No module named pytest`); it is untouched by this merge.

No conflict markers remain anywhere in the tracked tree.
