# Review — PR #26: Track click counts per link (schema change + backfill)

**Verdict: APPROVE.** The change is correct, safe (expand-first, idempotent),
consistent with the existing store, and its tests exercise real behavior against
real temp files. No blocking findings.

## Scope reviewed

`git diff main...HEAD` — all 6 changed files read in full:

| File | What changed |
|------|--------------|
| `.gitignore` | ignores the new sidecar `links.json.migrations.json` |
| `README.md` | documents `visit`, `clicks`, and the migration rail |
| `links.py` | adds `id`+`clicks` to records, `visit()`, `_write_all()`, `LinkNotFound`, CLI `visit` |
| `migrations.py` | **new** — versioned, batched, resumable backfill rail |
| `tests_backend.py` | +7 tests for id/clicks/visit |
| `tests_migrations.py` | **new** — 8 tests for the migration rail |

## Test evidence (final workspace action)

```
python3 tests_backend.py      → 13/13 passed   exit=0
python3 tests_migrations.py   →  8/8 passed    exit=0
python3 tests_markdown.py     →  4/4 passed    exit=0
```

## Correctness assessment

- **Expand-first schema change.** `add_link` now emits `id` (uuid4 hex) and
  `clicks: 0`; `url`/`title`/`added_at` are untouched, so old readers keep
  working. `markdown_export` (unchanged) only reads `title`/`url` — unaffected.
- **Idempotent backfill.** `_backfill_id_and_clicks` fills each field only when
  missing and reports `changed`, so a re-run over migrated rows is a no-op and
  never resets a non-zero `clicks` (verified by
  `test_backfill_does_not_reset_existing_clicks` and the byte-identical
  second-run assertion in `test_migrate_applies_twice_cleanly`).
- **Crash-safety holds in both orderings.** Each batch writes the full store
  *then* advances the durable cursor. If the write lands but the cursor save
  crashes, resume restarts that batch — safe because the per-field backfill is
  idempotent (no double-count). The resume test proves the cursor is honored.
- **`visit` guards a not-yet-backfilled row** with `record.get("clicks", 0)`
  and raises `LinkNotFound` for unknown ids / `ValueError` for blank ids — both
  covered.
- **Tests are behavioral**, not mocked: real temp `links.json` + real sidecar,
  seeded with genuine legacy rows (no `id`/`clicks`). They would fail if the
  change were reverted.

## Non-blocking notes (author's call — do not block merge)

- `suggestion (non-blocking):` `migrations.py` `_apply_one` rewrites the entire
  store file on every batch (O(n²) total write volume). Fine for this toy JSON
  store — batching here buys crash-resumability, not throughput — but worth a
  comment if the store ever grows large.
- `note (pre-existing):` `visit`/`add_link` are non-atomic read-modify-write of
  the whole file, so concurrent writers could lose an update. This is the
  store's existing single-writer assumption, not a regression introduced here.

## Decision

Correct, safe, and all three suites are green on my run. **tests_passed = true.**
