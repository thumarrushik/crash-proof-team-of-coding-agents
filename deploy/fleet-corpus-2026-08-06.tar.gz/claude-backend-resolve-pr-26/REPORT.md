# Merge conflict resolution — PR #26 (`claude/issue-6` ← `main`)

## Summary
Merged `origin/main` into `claude/issue-6`. Three files conflicted:
`links.py`, `tests_backend.py`, and `README.md`. Both sides were kept in every
case — neither side clobbered.

The two branches added independent features to the same store module:

- **This branch (`claude/issue-6`, issue #6)** — click tracking: a stable `id`
  and a `clicks` counter per record, a `visit(link_id)` function, the `visit`
  CLI verb, and a click column in `list` output (plus a migration backfill in
  `migrations.py`).
- **`main`** — Markdown export: an `export_markdown()` function and the `export`
  CLI verb.

## Conflicts and resolutions

### `links.py`
Kept **both** `visit()` and `export_markdown()`, both CLI verbs (`visit` and
`export`), the clicks-aware `list` output line, and both usage lines. The module
docstring now lists both public functions.

### `tests_backend.py`
Kept **both** test sets — the id/clicks/visit tests from this branch and the
`export_markdown` tests from `main` — and registered all of them in the `_run()`
battery.

### `README.md`
Kept both branches' Test-section entries. The comment now reads
"store + clicks/visit + markdown export behavior" and the migration/markdown
suites remain listed.

## Fixes to make the merged tree consistent
`main` shipped `tests_regression.py` with two assertions that pinned the record
schema to exactly `{url, title, added_at}`. This branch intentionally adds `id`
and `clicks` to every record, so those assertions are now stale. Updated both
(`test_add_returns_record_with_url_title_and_timestamp` and
`test_backing_file_is_a_json_list_of_records_with_exact_keys`) to assert the
merged schema `{id, url, title, added_at, clicks}`, preserving their exact-keys
coverage intent against the new reality.

## Verification (all green)
- `python3 tests_backend.py` → 15/15 passed
- `python3 tests_migrations.py` → 8/8 passed
- `python3 tests_markdown.py` → 4/4 passed
- `python3 tests_regression.py` → 30/30 passed
- `pytest tests/` (recency suite) → 16 passed
- No conflict markers remain in the tree.

**tests_passed: true**
