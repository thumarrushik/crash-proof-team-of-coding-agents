# Review — PR #23: Optimistic add-link with rollback (issue #9)

**Verdict: APPROVE.** The change is correct, safe, and its tests pass. It scaffolds
the linkbox frontend (Vite + React + React Query) and implements optimistic
add-link with rollback exactly as the issue describes. No blocking findings.

## Evidence

- `npm run test` (final workspace action) → `Test Files 1 passed (1) | Tests 7 passed (7)`, exit 0.
- `npm run typecheck` (`tsc --noEmit`) → exit 0, no errors.

## Scope reviewed

Full `git diff main...HEAD` read except `package-lock.json` (3.8k generated lines,
scanned not line-read). Source files reviewed in full: `src/api.ts`,
`src/useLinks.ts`, `src/LinkBox.tsx`, `src/App.tsx`, `src/main.tsx`,
`src/LinkBox.test.tsx`, `src/test/setup.ts`, `src/test/server.ts`, `src/styles.css`,
and config (`vite.config.ts`, `tsconfig.json`, `package.json`, `index.html`).

## What the change does well

- **Textbook React Query optimistic pattern** (`src/useLinks.ts`): `onMutate`
  cancels in-flight queries, snapshots the cache, inserts the optimistic entry;
  `onError` restores the exact snapshot; `onSettled` invalidates to re-sync with
  server truth. Rollback context is typed and threaded correctly.
- **Failure is surfaced, not swallowed**: `ApiError` is thrown for any non-2xx,
  retries are disabled so it reaches the user, and the mutation error alert
  preserves the user's input for retry (`src/LinkBox.tsx`, `onSuccess` clears the
  draft only after acceptance).
- **Tests are behavioral and cover the failure branch**: rollback, empty-field
  validation (asserts no POST fired), load error + retry, loading, empty, and the
  success reconciliation (optimistic id → real server id). They would fail if the
  feature were reverted.
- Accessibility is considered (roles, `aria-busy`, `aria-describedby`, focus-visible,
  44px targets), and `rel="noreferrer noopener"` is set on rendered links.

## Non-blocking findings

- `suggestion (non-blocking): src/LinkBox.tsx:8` — the rendered `<a href={link.url}>`
  performs no URL scheme validation, and the form sets `noValidate`, bypassing the
  `type="url"` check. A `javascript:` URL would be a self-XSS vector. Low real-world
  risk for a single-user personal link collection (the user would be attacking
  themselves), so not blocking, but worth a scheme allowlist (`http`/`https`) when
  the backend lands.
- `nitpick (non-blocking): src/LinkBox.tsx:5` — optimistic rows are detected via
  `link.id.startsWith("optimistic-")`, an implicit coupling to the id format minted
  in `useLinks.ts`. Works, but a boolean flag on the row would be less fragile.
- `nitpick (non-blocking): src/LinkBox.tsx` — inputs stay enabled while the mutation
  is pending (only the button is disabled), so an Enter keypress could fire a second
  concurrent `mutate`. Narrow edge; consider disabling the fields during `isPending`.
- `question: src/useLinks.ts:66` — if the `onSettled` invalidation refetch itself
  fails, `LinkList` renders the load-error state (it checks `isError` before data),
  briefly hiding a link that was actually saved. Acceptable edge behavior; noting it
  as intended-or-not.

## Operational note

This is a frontend-only PR; `/api/links` has no backend or Vite dev proxy in this
diff (the backend is a separate lane, per the comment in `src/api.ts`). Tests mock
the boundary with MSW. That is consistent with the PR's stated scope and does not
block.
