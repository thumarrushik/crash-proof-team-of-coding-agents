# Task Report — Review of PR #21 (`claude/issue-5`): API dates must be ISO 8601

**Verdict: BLOCK (tests_passed = false).** The feature is well-built and all
66 tests pass, but the PR performs a canonical-storage schema change
(`added_at` ISO string → `created_at` epoch integer) with **no data migration**,
which makes both API routes return HTTP 500 for any store written by the
previous release. One blocking issue, listed first.

## Blocking findings

### issue (blocking): schema change with no migration — legacy rows 500 both routes
- **Where:** `links.py:88` (record now writes `created_at`, no longer writes
  `added_at`); `migrations.py:96-97` (migration rail still stops at migration 1,
  id+clicks only — no migration to backfill `created_at`); `app.py:59` &
  `app.py:68` (`serialize_v0`/`serialize_v1` read `record["created_at"]`).
- **What breaks:** The previous release stored each record with `added_at`
  (ISO string) and no `created_at`. This PR renames/retypes that canonical
  field but ships no migration to convert existing rows, and running the
  migration rail does **not** add `created_at`. When the API then serializes a
  legacy record it raises `KeyError('created_at')`, which the handler converts
  to a 500 for the **entire** list — so a single legacy row takes down both
  `GET /v0/links` and `GET /v1/links`. The CLI `list` verb
  (`links.py:142`) breaks the same way.
- **Why it blocks:** The PR's central promise is "keep `/v0` working for
  existing consumers while introducing `/v1`." Existing consumers have existing
  data, and existing data yields 500 on *both* routes — the compatibility
  guarantee fails for exactly the population it is meant to protect. This is
  also a direct violation of the project's own migration discipline
  (`migrations.py:3-13`: "schema changes to *live* `links.json` data flow
  through numbered, idempotent migrations — never ad-hoc rewrites"); migration 1
  backfilled `id`/`clicks` for old rows, but no migration 2 backfills
  `created_at`.
- **Reproduction (run against the PR tree):** seed a store with one legacy
  record `{id,url,title,added_at,clicks}` (no `created_at`), run
  `migrations.migrate()`, then `app.serialize_v1(record)` →
  `KeyError: 'created_at'`; `links.list_links()[0]["created_at"]` → same.
  Verified live: migrate reports `rows_changed: 0` and the record still lacks
  `created_at`.
- **What fixed looks like:** add migration 2 to the rail that derives
  `created_at` from `added_at` (parse the ISO string to epoch) or from a
  sensible default, and drop `added_at`; add a test covering the upgrade path
  (legacy `added_at` row → served shape). The related stale note at
  `migrations.py:12` ("never touches … `added_at`, so the previous release keeps
  reading the same rows unchanged") should be corrected once the field is
  migrated.

## Non-blocking observations

- **suggestion:** `tests_contracts.py` / `tests_backend.py` / `tests_regression.py`
  all exercise only green-field stores. There is no test for the upgrade path
  (a record written by the prior schema). Adding one would have caught the
  blocker above (missing test delta for a behavior delta).
- **nitpick:** the 404 branch in `app.py` returns `code: "ERR_MISSING_FIELD"`
  with `field: "path"` for an unknown route; a missing route is not a missing
  field. Cosmetic; tests pin it.
- **note (positive):** the versioning design itself is sound — `/v1` added
  beside `/v0` rather than mutating `/v0`, RFC 8594 `Deprecation`/`Sunset`/`Link`
  headers, canonical `{data}`/`{error}` envelope, loud 500 instead of leaked
  HTML, and real-HTTP contract tests that pin both shapes and the headers.

## How it was verified
Ran every suite in the workspace as the final action (all green):
- `python3 tests_backend.py` → 17/17 passed (exit 0)
- `python3 tests_contracts.py` → 7/7 passed (exit 0)
- `python3 tests_markdown.py` → 4/4 passed (exit 0)
- `python3 tests_regression.py` → 30/30 passed (exit 0)
- `python3 tests_migrations.py` → 8/8 passed (exit 0)

Total 66/66. The suites are green because none exercises the pre-existing-data
upgrade path; a standalone repro (legacy `added_at` record → migrate → serialize)
reproduced the `KeyError('created_at')` → 500 described above.

## Files reviewed
- `links.py` — `added_at` → `created_at` epoch, `add_link(created_at=None)`, CLI.
- `app.py` — new HTTP transport, v0/v1 serialization, deprecation headers.
- `tests_contracts.py` — new real-HTTP contract tests.
- `tests_backend.py`, `tests_regression.py` — realigned to `created_at`.
- `migrations.py` — read for migration coverage (unchanged by PR; the gap).
- `README.md`, `REPORT.md` (this file) — docs.
- `linkbox/recency.py` — confirmed independent in-memory model, unaffected.
