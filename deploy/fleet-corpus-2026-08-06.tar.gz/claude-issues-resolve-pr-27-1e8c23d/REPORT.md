# Merge conflict resolution — PR #27 (`claude/issue-13` ← `main`)

## Summary
Merged `origin/main` into `claude/issue-13` to clear the merge block on PR #27.
All source code merged automatically without conflict; git surfaced a single
content conflict, in `REPORT.md` — the per-run report doc, where this branch's
old report (an earlier PR #27 write-up) collided with `main`'s report from the
PR #26 (`claude/issue-6`) merge. No code was clobbered on either side.

## The two intents (both preserved by the clean auto-merge)
- **This branch (`claude/issue-13`, issue #13)** — improved duplicate-link
  handling in the JS store: `src/linkStore.js` treats a URL saved twice (or with
  surrounding whitespace) as the same row instead of creating a duplicate,
  covered by the `node:test` suite in `test/linkStore.test.js`.
- **`main`** — the Python link store plus its click-tracking, markdown-export,
  migration, and recency work (`links.py`, `migrations.py`, `markdown_export.py`,
  the `tests_*.py` batteries, `tests/`), and the React/Vite/vitest frontend.

Both sides land intact: the merged tree keeps `main`'s full Python + frontend
config and this branch's `linkStore.js` deduplication. The already-merged
`package.json` `test` script runs **both** JS runners (`vitest run && node --test`)
and `vite.config.ts` excludes `test/**` from vitest so the two runners don't
collide.

## Conflict resolution
### `REPORT.md`
Replaced the two stale, mutually-conflicting reports with this single accurate
report for the current resolution. Nothing else in the tree conflicted.

## Verification (all green after the merge)
JavaScript:
- `npm ci` → dependencies installed, exit 0.
- `npm test` → vitest **5/5** (`src/components/LinksPage.test.tsx`) + node:test
  **5/5** (`test/linkStore.test.js`), exit 0.
- `npm run typecheck` (`tsc --noEmit`) → no errors, exit 0.

Python:
- `pytest tests/` (recency suite) → **16 passed**.
- `python3 tests_backend.py` → **15/15**.
- `python3 tests_migrations.py` → **8/8**.
- `python3 tests_markdown.py` → **4/4**.
- `python3 tests_regression.py` → **30/30**.

- No conflict markers remain anywhere in the tracked tree.

**tests_passed: true**
