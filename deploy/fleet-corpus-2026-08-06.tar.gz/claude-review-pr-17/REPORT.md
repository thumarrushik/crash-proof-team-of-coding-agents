# Review — PR #17 (issue #14): README: document how to run the tests

**Verdict: APPROVE** — `tests_passed=true`

## Scope
Docs-only change. Adds a `## Development` section to `README.md` covering Install,
Run, and Test. `README.md` is the only file touched (+21/−1). No source, config, or
test code changed.

## Verification (evidence)
- **Test suite runs as documented.** `python3 tests_backend.py` → `6/6 passed`,
  exit code `0`, matching the README's "exit code 0 = every test passed" claim.
- **CLI commands are accurate.** `python3 links.py add https://example.com "Example"`
  and `python3 links.py list` both execute successfully as documented (README lines 49–51).
- **Python 3.8+ claim holds.** `links.py`/`tests_backend.py` use only stdlib
  (`json`, `os`, `datetime.timezone`) and f-strings — no syntax newer than 3.8. Claim accurate.
- **"pure Python stdlib, no dependencies" claim holds.** No third-party imports; no
  requirements file in the repo.

## Findings
None blocking. Minor (non-blocking): the clone URL `github.com/thumarrushik/linkbox`
could not be validated from the workspace, but it is consistent with the system repo
reference already in the README and is a docs-only nicety.

## Risk
Negligible — documentation only, no runtime or security surface.
