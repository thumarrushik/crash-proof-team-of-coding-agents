# Merge Conflict Resolution — PR #20 (`claude/issue-8` ← `main`)

## Summary
Merged `origin/main` into `claude/issue-8` and resolved the single conflict.
The two branches were largely orthogonal: `claude/issue-8` adds the frontend
React/TypeScript "Links list page" (issue #8), while `main` added a stdlib
Python backend (`links.py`, `markdown_export.py`) plus docs. Git auto-merged
every file except `.gitignore`.

## Conflicts resolved

### `.gitignore` (add/add conflict)
Both sides created a `.gitignore`. Kept **both** sets of entries — the
frontend's Node/TypeScript ignores and the backend's Python ignores — so
neither lane loses coverage:

```
node_modules/
dist/
coverage/
*.tsbuildinfo
*.log
.DS_Store
__pycache__/
*.pyc
links.json
```

No other files conflicted; the frontend and backend file sets do not overlap.

## Verification (all passing after resolution)
- Frontend unit tests — `npm run test` (vitest): **5/5 passed**
- Frontend typecheck — `npm run typecheck` (tsc --noEmit): **clean**
- Backend tests — `python3 tests_backend.py`: **6/6 passed**
- Markdown tests — `python3 tests_markdown.py`: **4/4 passed**
- No leftover conflict markers anywhere in the tree.

## Notes
Only the merge resolution was committed. Harness-injected, untracked files
(`.claude/`, `CLAUDE.md`) and ignored `node_modules/` were intentionally not
staged. The branch was not pushed (the harness handles push + re-merge).
