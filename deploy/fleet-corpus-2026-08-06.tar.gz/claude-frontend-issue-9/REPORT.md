# Task Report

## What was built
Issue #9 asked for optimistic add-link with rollback. The product code
(`useLinks.ts` add mutation + `LinkBox.tsx`) already implemented the full
contract — snapshot the previous cache in `onMutate`, insert a temporary entry
so the link appears instantly, roll back to the snapshot in `onError`, surface
the failure to the user while preserving their input, and re-sync from the
server in `onSettled`. The gap was proof: there was no test suite, so the
failure branch had no test at all. This change adds the missing coverage —
`src/LinkBox.test.tsx` — exercising all four render states plus the optimistic
add success **and** failure/rollback branches with equal weight, satisfying the
issue's "done when" criterion. It also fixes a jsdom/undici realm mismatch in
`src/test/setup.ts` so the app's real query-cancellation `AbortSignal` works
under the test environment.

## How it was verified
- `npm test` (vitest run) → **7 passed (7)**. Covers loading (role=status),
  empty, load-error + working Retry, success list, optimistic-add success
  (instant "Saving…" row → reconciles to server truth, input cleared only on
  success), and optimistic-add failure (row rolls back, error alert shown,
  input preserved), plus client-side validation blocking an empty-field submit.
- `npm run typecheck` (tsc --noEmit) → **exit 0**, no errors.
- No Playwright/e2e or backend suite exists in this workspace; the
  Testing-Library + MSW integration suite (real component + hooks + mocked HTTP
  boundary, queried by role/label) is the coverage layer per the testing
  trophy. Assumption noted here rather than stalling.

## Files
- `src/LinkBox.test.tsx` (created) — integration tests for the four render
  states and the optimistic add success/failure branches.
- `src/test/setup.ts` (modified) — normalize the fetch boundary so jsdom's
  `AbortSignal` (which Node's undici `fetch`/`Request` reject) does not break
  the app's real query-cancellation code under test; behavior under test is
  unaffected.
- `REPORT.md` (created) — this report.
