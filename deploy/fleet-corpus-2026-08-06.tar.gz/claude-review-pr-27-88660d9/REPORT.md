# Review — PR #27 (`claude/issue-13`): Improve duplicate link handling

**Verdict: APPROVE — tests_passed: true**

## Scope of the change
`git diff main...HEAD` touches four meaningful files (plus recompiled `*.pyc`
byte-code noise):

- **`src/linkStore.js`** (new) — a small in-memory `LinkStore` whose `save(url)`
  is idempotent: it trims surrounding whitespace and returns the existing row
  when the normalized URL is already stored, instead of creating a duplicate.
  Rejects non-string / empty / whitespace-only input with a `TypeError`.
- **`test/linkStore.test.js`** (new) — a `node:test` suite (5 cases) covering
  new-URL insert, duplicate no-op, whitespace-equivalence, distinct URLs, and
  input validation.
- **`package.json`** — adds a `description`; test script now runs both runners:
  `vitest run && node --test 'test/**/*.test.js'`.
- **`vite.config.ts`** — excludes `test/**` from vitest so the two runners
  don't fight over the same files.

## Correctness
- Dedup logic is correct: `url.trim()` normalization + linear match on
  `row.url === normalized`; returns the existing row on a repeat save. The
  behavior matches the docstring and every test asserts it.
- Input validation is sound (`typeof !== 'string' || trim() === ''` → `TypeError`).
- `all()` returns a defensive copy (`slice()`), preserving insertion order.

## Tests (all green in this workspace, Node v24.3.0)
- `npm test` → vitest **5/5** (`src/components/LinksPage.test.tsx`) +
  node:test **5/5** (`test/linkStore.test.js`); **exit 0**.
- `npm run typecheck` (`tsc --noEmit`) → no errors, **exit 0**.
- `node --test 'test/**/*.test.js'` independently → 5 pass, 0 fail.

## Security / operational risk
- Pure in-memory module, no I/O, no network, no user-controlled sink; no
  injection or resource concerns. Nothing to flag.
- The dual-runner test script is the only operational change and both runners
  pass cleanly; the vitest `exclude` prevents cross-runner collision.

## Non-blocking observations (not defects in the feature)
1. `node --test '<glob>'` relies on the test runner's glob support (Node ≥ 21).
   It works here on Node v24; `package.json` has no `engines` pin, so on an
   older Node the glob would match nothing and pass vacuously. Low risk given
   the toolchain (vitest 2.x already requires modern Node).
2. Normalization is whitespace-trim only — it does not canonicalize scheme
   case or trailing slashes, so `https://example.com` and `.../` remain
   distinct. This is an honest, scoped improvement, not a bug; the code does
   exactly what it documents.
3. Tracked `*.pyc` files churn in the diff even though `.gitignore` lists
   `__pycache__/`/`*.pyc`. These were already tracked before this PR and are a
   repo-wide hygiene issue, not introduced by this change.
4. `LinkStore` is a self-contained module not yet wired into the React app or
   the Python store — consistent with the per-issue module pattern in this repo.

None of the above blocks merge. The change is correct, safe, well-tested, and
its tests pass.

**tests_passed: true**
