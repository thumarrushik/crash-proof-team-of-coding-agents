# PR #22 conflict resolution — `claude/issue-4` ← `main`

## Summary

Merged the current `origin/main` into `claude/issue-4` and resolved every
conflict by hand, keeping **both** sides intact. This branch adds the tags
feature (issue #4); `main` had meanwhile advanced with the click-tracking
(`id`/`clicks`/`visit`) and Markdown-export features. The two feature sets are
orthogonal on the shared `links` store, so the merged store carries all of them.

## Conflicts resolved

### `links.py` (3 hunks)
- **Module docstring** — merged both public-API lists into one, and the example
  record now shows the full merged shape
  `{id, url, title, tags, added_at, clicks}`.
- **`add_link` / `_write_all`** — kept `main`'s `_write_all` write choke point
  **and** this branch's `add_link(url, title, tags=None)` signature. The shared
  function body (already carrying `id`, `tags`, `clicks`) was unchanged.
- **CLI (`__main__`)** — merged the verb tables: `add <url> <title> [tag ...]`
  (now also prints the new `id`), `list [tag]` (now also prints the `clicks`
  column), plus `main`'s `visit <id>` and `export` verbs and the combined usage
  block.

### `tests_backend.py` (2 hunks)
- Kept **both** test sets — this branch's six tags tests and `main`'s
  id/clicks/visit and export-markdown tests — and registered all of them in the
  `_run()` battery. Now 21 tests.

### `REPORT.md` (add/add)
- Rewritten for this PR #22 resolution (this file).

## Fixes to make the merged tree consistent

`main`'s `tests_regression.py` pinned the record schema to exactly
`{id, url, title, added_at, clicks}` in two exact-keys assertions
(`test_add_returns_record_with_url_title_and_timestamp` and
`test_backing_file_is_a_json_list_of_records_with_exact_keys`). This branch
adds a `tags` field to every record, so both were updated to the merged schema
`{id, url, title, tags, added_at, clicks}`, preserving their exact-keys intent.

## Files merged cleanly (from `main`, no conflict)
- `migrations.py`, `tests_migrations.py` — id/clicks backfill migration.
- `markdown_export.py`, `tests_markdown.py` — Markdown export.
- `tests_regression.py` (then adjusted, above), `linkbox/`, `tests/` recency
  suite, and the React/TS frontend (`src/`, `index.html`, `package*.json`,
  `pyproject.toml`, `vite.config.ts`, `tsconfig.json`).

## Tests / checks

All backend suites affected by the merge pass after resolution:

- `python3 tests_backend.py`     → 21/21 passed
- `python3 tests_markdown.py`    → 4/4 passed
- `python3 tests_contract.py`    → 9/9 passed
- `python3 tests_migrations.py`  → 8/8 passed
- `python3 tests_regression.py`  → 30/30 passed

**Total: 72/72 passing.** No conflict markers remain in the tree.

The pytest recency suite (`tests/`) and the vitest frontend suite came in from
`main` and are gated on `pytest` / `npm` toolchains that are not installed in
this workspace (no `pip`/`pytest` module available); they are untouched by this
backend-lane merge.

**tests_passed: true**
