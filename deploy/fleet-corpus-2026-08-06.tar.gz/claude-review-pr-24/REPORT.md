# Review — PR #24: Flaky recency test fails near midnight (closes #11)

**Verdict: APPROVE (tests_passed=true)**

## Summary
The PR implements the `recency` slice of `linkbox` and deflakes issue #11 by
**injecting the current instant** rather than reading the wall clock twice. A
single `now` value decides both the link's timestamp and the "is it today?"
boundary, eliminating the midnight-rollover race where a stamp taken at
23:59:59 (day D) was compared against a "today" recomputed at 00:00:00 (day
D+1).

## What I checked
- **Diff correctness** — `git diff main...HEAD`. `recently_added(links, now)` is
  a pure function; `LinkStore` owns one clock and reads it once at the query
  boundary (`self._clock() if now is None else now`). The fix targets the root
  cause (two independent clock reads), not the symptom.
- **Tests pass** — `pytest -q` → **16 passed**.
- **Anti-flake proof** — `RUNS=10 bash tests/run_battery.sh` → **BATTERY GREEN:
  10/10**. The suite also includes a boundary parametrization across the last/
  first seconds of the day and an in-suite 10x determinism check.
- **Test quality** — The conviction test
  (`test_independent_clock_reads_drop_the_just_added_link_across_midnight`)
  deterministically reproduces the *pre-fix* hazard via a `SteppingClock`, and
  the paired test proves the fix keeps the link at the same boundary. Behavior
  tests cover today/yesterday/tomorrow, first/last instant of day, order
  preservation, and empty input. Tests are deterministic by construction (no
  real-clock reads, no sleeps, no retries).

## Non-blocking findings
1. **Committed build artifacts** — `linkbox/__pycache__/*.pyc` and
   `tests/__pycache__/*.pyc` are checked in, and there is no `.gitignore`.
   These are generated files and should not be tracked. Recommend `git rm
   --cached` them and add a `.gitignore` with `__pycache__/`. Cosmetic; does not
   affect behavior or correctness, so it does not block the merge.

## Notes
- `added_at.date() == now.date()` compares naive local dates — consistent with
  the issue's "same local calendar day" semantics and adequate for this slice's
  scope.

No correctness, security, or operational blockers found. The change is correct,
its tests are deterministic and pass, and the flake's root cause is removed.
