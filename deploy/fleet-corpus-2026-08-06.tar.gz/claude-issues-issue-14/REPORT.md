# Issue #14 — README: document how to run the tests

## What changed and why
The README described what linkbox is and how to use the store, but never told a
newcomer how to set the project up or run its tests as a single, copy-paste
workflow. Added a `## Development` section to `README.md` with three
copy-paste-runnable steps — **Install**, **Run**, **Test** — consolidating the
setup/usage/test path in one place. The pre-existing standalone "Run the tests"
trailing block was folded into this section's **Test** step to avoid duplication.

Docs-only change: no source or test files touched.

## Acceptance
- **Scope:** Add a "Development" section to the README covering install, run,
  and test, each copy-paste runnable. → Satisfied by the new `## Development`
  section in `README.md` (lines 34–58).
- Every documented command was executed and verified before writing:
  - `git remote -v` → clone URL is `https://github.com/thumarrushik/linkbox.git`
    (used in the Install step; the README's existing "System:" link points at
    the meta-system repo, so I used the actual `linkbox` remote instead).
  - `python3 links.py add … / list` → runs and prints the stored record.
  - `python3 tests_backend.py` → `6/6 passed`, exit code 0.
  - Python floor stated as 3.8+ is conservative: the code uses only stdlib
    (`json`, `os`, `datetime`, `tempfile`) and f-strings, all ≥3.6.

## Tests — final run (last workspace action)
Command:
```sh
python3 tests_backend.py
```
Output tail:
```
PASS  test_add_creates_file_when_missing
PASS  test_list_returns_added_links
PASS  test_list_is_newest_first
PASS  test_persistence_across_reads
PASS  test_empty_store_lists_nothing
PASS  test_add_rejects_blank_input

6/6 passed
```
Exit code: 0. `tests_backend.py` is the only suite the repo ships.

## Noticed, not changed
- The README's top-of-file "System:" link (line 8) points at the
  `crash-proof-team-of-coding-agents` repo, not `linkbox`. Left as-is — it
  intentionally references the system, and changing it is outside this issue's
  scope.
- No CI config or linter ships with the repo; nothing to document beyond the
  single test suite.

## Residual risk
Minimal. The change is documentation only; every command in the new section was
run and observed to succeed. A temporary `links.json` created while verifying
the CLI was removed (it is gitignored regardless). Working tree contains only
the intended `README.md` edit plus the harness-stamped `.claude/` and
`CLAUDE.md`.
