# Review — PR #16: Bug: markdown export breaks on `]` in link titles (issue #7)

**Verdict: APPROVE** — correct, safe, tests pass.

## What the PR does
Adds a new standalone module `markdown_export.py` exposing `to_markdown(links)`,
which renders link records (`{"title", "url"}`) as `- [title](url)` bullet
lines. Square brackets in the title are backslash-escaped via `_escape_title`
(`[` → `\[`, `]` → `\]`), directly fixing issue #7 where an unescaped `]` closed
the link text early. Adds `tests_markdown.py` with plain-assert tests.

## Correctness
- The root cause of issue #7 — a `]` inside the `[title]` segment terminating
  the link text — is resolved by escaping both brackets. Verified:
  `to_markdown([{"title":"a]b[c","url":"u"}])` → `- [a\]b\[c](u)` (renders as
  literal brackets). `markdown_export.py:15`
- Empty input returns `""` as documented. `markdown_export.py:22`
- Escape order (`[` then `]`) is safe — the two replacements don't interact.

## Tests
`python3 tests_markdown.py` → **4/4 passed**, exit 0. Coverage: plain title,
bracketed title (the issue #7 regression), multiple links (one per line), and
empty list. Tests drive the real module against plain dicts, no mocks.

## Notes (non-blocking, out of scope for issue #7)
- URLs containing `)` (or `(`) can still break the `(url)` segment; titles with
  a literal newline would break the one-line-per-link format. Neither is part of
  this issue and the links store is not present in-repo to exercise them. Worth a
  follow-up issue if such inputs become reachable, but not a blocker here.
- No callers exist yet (seed module per README); nothing to integrate against.

## Decision
Change is minimal, correct, and safe; its tests pass and cover the regression.
**tests_passed = true** (approve + merge).
