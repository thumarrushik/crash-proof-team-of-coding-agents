# REPORT — Backend: links store with tests (issue #1)

## What was built
A stdlib-only link store and its test suite.

- **`links.py`**
  - `add_link(url, title)` — appends a record to `links.json`, creating the file
    (and any parent dir) if missing. Returns the stored record
    `{url, title, added_at}`. Rejects blank/non-string `url` or `title` with
    `ValueError` (fail loud).
  - `list_links()` — returns all records **newest first**.
  - Ordering is derived by reversing append (chronological) order, so it is
    correct regardless of timestamp clock resolution.
  - Includes a small `__main__` CLI (`add` / `list`) for manual use.
- **`tests_backend.py`** — six plain-assert tests, runnable with
  `python3 tests_backend.py` (exit 0 = pass). Each test drives the real module
  against a real temporary JSON file (no mocks) by repointing
  `links.LINKS_FILE`.
- **`README.md`** — added a "Links store" section with a Python snippet, CLI
  usage, and the test command.
- **`.gitignore`** — keeps runtime artifacts (`__pycache__/`, `links.json`) out
  of version control.

## Contract classification
Not a served HTTP endpoint and not a shared-storage schema, so the
[[api-contracts]] and [[data-migrations]] rails do not apply. This is a
new, self-contained stdlib module — the smallest correct change is the two
functions plus a JSON file, per the issue. `LINKS_FILE` is exposed as a module
attribute so callers/tests can redirect the store without changing the public
`add_link`/`list_links` signatures.

## Tests
```
$ python3 tests_backend.py
PASS  test_add_creates_file_when_missing
PASS  test_list_returns_added_links
PASS  test_list_is_newest_first
PASS  test_persistence_across_reads
PASS  test_empty_store_lists_nothing
PASS  test_add_rejects_blank_input

6/6 passed
exit=0
```

Coverage: file creation on first add, list contents, newest-first ordering,
persistence across a simulated fresh read, empty-store behavior, and
blank-input rejection.

## Self-review notes
- **Correctness:** newest-first verified by an explicit ordering assertion.
- **Edge cases:** missing file, empty store, blank/whitespace input all covered.
- **Security:** JSON-only parsing (no `eval`); corrupt non-list files fail loud.
- **Leftovers:** no TODOs, stubs, or commented-out code.
- **Conventions:** stdlib-only, docstrings, matches the tiny-repo style.

## Assumptions
- A record shape of `{url, title, added_at}` was chosen; the issue only
  mandated `url` and `title`, and `added_at` is additive/harmless.
- Single-process usage assumed (no file locking), appropriate for this tiny
  store.
