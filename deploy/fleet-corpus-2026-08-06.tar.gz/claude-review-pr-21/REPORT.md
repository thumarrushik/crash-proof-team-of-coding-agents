# Review — PR #21: API dates must be ISO 8601 (breaking change) (closes #5)

**Verdict: APPROVE / merge.** The change is correct, well-designed, and both
test suites are green on my own run (evidence below).

## What the PR does

Issue #5 asks that API dates be ISO 8601 — a breaking change to `created_at`'s
served type. The PR implements the correct pattern for a breaking field-type
change: instead of editing the existing shape in place, it serves two versions
side by side and keeps storage version-independent.

- `links.py` — stdlib store. `created_at` stored as the canonical **unix epoch
  integer** (UTC). `add_link` validates non-blank url/title, coerces
  `created_at` to `int`, appends chronologically; `list_links` returns newest
  first; `_read_all` fails loud on a non-list backing file.
- `app.py` — stdlib `http.server`. `GET /v0/links` serves the raw epoch int
  (**deprecated**); `GET /v1/links` serves an ISO 8601 UTC string derived from
  the same epoch. Canonical `{"data"}`/`{"error"}` envelope. `/v0` advertises
  retirement via RFC 8594 `Deprecation`/`Sunset`/`Link: rel="successor-version"`
  headers. Unknown exceptions render the 500 envelope instead of leaking the
  handler's default HTML page.
- Two behavioral test suites (store over a real temp file; API over real HTTP).

## Inspection (read every changed line: app.py, links.py, both suites, README)

- **Design** — Correct. Confirmed via `git show main:app.py` that `app.py`,
  `links.py`, and the tests are entirely net-new (main held only the README),
  so there is no pre-existing consumer of a `/links` route being broken. The
  versioned side-by-side approach is exactly right for a breaking type change,
  and storage stays as the version-independent epoch. Belongs here; improves
  code health.
- **Functionality** — Verified `to_iso8601_utc(1700000000) == "2023-11-14T22:13:20Z"`
  and that the README's example epoch `1754481296` renders to its documented
  `"2025-08-06T11:54:56Z"`. `+00:00`→`Z` normalization is correct ISO 8601 UTC.
  Edges covered: empty store, missing file, corrupt file (→ 500 envelope),
  unknown route (→ 404 envelope), duplicate/newest-first ordering.
- **Complexity** — Minimal and readable; no speculative generality.
- **Tests** — Behavioral and would fail if reverted: they pin `created_at`'s
  type per version (int vs str), assert the ISO string parses back to the exact
  seeded instant, cover the failure branches (corrupt store → 500, unknown
  route → 404), and assert `/v1` carries **no** deprecation headers. The
  traceback printed during the contract run is expected output from
  `test_corrupt_store_fails_loud` (the handler's `traceback.print_exc`); that
  test PASSes.
- **Naming/comments/consistency** — Clear and consistent; docstrings match
  behavior; README table matches the served shapes.

## Non-blocking findings (author's call — none block merge)

- `suggestion (non-blocking): app.py:135` — the 404 for an unknown route uses
  `code="ERR_MISSING_FIELD"` with `field="path"`. Semantically a missing route
  is not a missing field; a code like `ERR_NOT_FOUND` would read truer. Tested
  and internally consistent, so not blocking.
- `suggestion (non-blocking): app.py:117` — the 500 message interpolates `{exc}`,
  which for the corrupt-store case echoes the backing file's absolute path to
  the client (minor information disclosure). Fine for a localhost-bound toy
  service; consider a generic client message with detail kept to the server log.

## Test evidence (my run, final workspace action)

```
$ python3 tests_backend.py
8/8 passed          (exit 0)

$ python3 tests_contracts.py
7/7 passed          (exit 0)
```

Both suites exit 0 with zero failures and zero errors → `tests_passed = true`.
