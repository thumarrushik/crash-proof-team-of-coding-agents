# Issue #2 — Export: markdown list of saved links

## Summary
Added `export_markdown()` to `links.py`, returning the saved links as a
Markdown bullet list (`- [title](url)`), newest first. Documented a
`python3 -c` usage example in `README.md` and extended `tests_backend.py`
to cover the empty store and the 2+ link case. Stdlib-only, no new deps.

## Changes
- **`links.py`**
  - New `export_markdown() -> str`: joins `- [title](url)` lines built from
    `list_links()` (already newest-first). Returns `""` for an empty store.
  - Added an `export` CLI subcommand for parity with `add`/`list`.
  - Updated the module docstring public-API list.
- **`tests_backend.py`**
  - `test_export_markdown_empty_store`: empty store → `""`.
  - `test_export_markdown_lists_newest_first`: 2 links → newest-first bullets.
- **`README.md`**
  - Added a `python3 -c 'import links; print(links.export_markdown())'` example
    with sample output.

## Design notes
- Reuses `list_links()` (single source of truth for ordering) rather than
  re-reading/re-sorting, so newest-first behavior stays consistent.
- Empty store returns an empty string (no trailing newline), which `print`
  renders as a single blank line — natural for shell piping/redirection.

## Verification
`python3 tests_backend.py` → **8/8 passed** (exit 0), including the two new
tests. Manually confirmed the README `python3 -c` example produces the
documented output.
