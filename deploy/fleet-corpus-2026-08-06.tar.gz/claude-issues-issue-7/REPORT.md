# Task Report

## What was built
Fix for issue #7: square brackets in link titles broke the Markdown export.
`markdown_export.to_markdown` now runs each title through `_escape_title`, which
backslash-escapes `[` and `]` so a bracket in a title can no longer close the
`[title]` link text early. Scope is exactly the reported bug — a title like
`My [favorite] site` now exports as `- [My \[favorite\] site](https://…)`, which
renders as one correct link in Markdown viewers instead of the malformed
`- [My [favorite] site](https://…)`.

Acceptance: brackets in titles are escaped so the exported list renders
correctly — shown by `test_brackets_in_title_are_escaped`, which freezes the
issue's exact reproduction (`My [favorite] site`) and asserts the escaped output.
I verified the test is a genuine guard: with the escape removed the module emits
the exact malformed line from the issue and the frozen expectation rejects it
(red), and the shipped module produces the escaped line (green).

## How it was verified
- Red/green guard proof (inline script): simulated the pre-fix unescaped render →
  produced `- [My [favorite] site](https://example.com)` (the issue's malformed
  line), which fails the frozen expectation; the real module produces
  `- [My \[favorite\] site](https://example.com)`, which passes.
- Final full suite: `python3 tests_markdown.py` → `4/4 passed`, exit code `0`
  (`test_plain_title_renders_as_link`, `test_brackets_in_title_are_escaped`,
  `test_multiple_links_one_per_line`, `test_empty_list_is_empty_string`).

## Files
- `markdown_export.py` — `to_markdown` plus the `_escape_title` bracket-escaping helper.
- `tests_markdown.py` — plain-assert suite including the issue #7 regression test.
- `REPORT.md` — this report.

## Noticed, not changed
- URLs are not escaped (e.g. `)` in a URL); out of scope for this issue, which is
  about `]` in titles. No repro reported for URLs.
- A title already containing a literal backslash before a bracket (`\]`) becomes
  `\\]`; a rare edge with no reported repro. Left as-is to keep the change minimal.

## Residual risk
Low. The change is confined to title rendering in one small pure function; the
full suite passes and the regression test is proven to fail without the fix.
