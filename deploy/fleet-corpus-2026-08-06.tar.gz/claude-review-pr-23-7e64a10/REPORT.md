# Review — PR #23: Optimistic add-link with rollback (issue #9)

**Verdict: APPROVE (tests_passed=true).** The optimistic add-link flow is a
textbook-correct TanStack Query implementation with proper rollback and honest
error surfacing. Tests, typecheck, and production build all pass. No blocking
issues found.

## What I ran (evidence)

- `npm test` → **12 passed (2 files)**, incl. 7 new LinkBox tests.
- `npm run typecheck` (`tsc --noEmit`) → **exit 0**.
- `npm run build` (`tsc -b && vite build`) → **built successfully**.

## What the PR does

Adds an optimistic add-link surface (`LinkBox`) alongside the base branch's
`LinksPage`, wired through a new API boundary (`api.ts`) and a query/mutation
hook layer (`useLinks.ts`). Each surface gets its own isolated `QueryClient`.

## Correctness review

The mutation in `src/useLinks.ts` follows the canonical optimistic pattern
correctly:

- `onMutate` cancels in-flight queries (prevents a refetch clobbering the
  optimistic write), snapshots `previous`, inserts a temp entry keyed
  `optimistic-<uuid>`, and returns the snapshot as context.
- `onError` restores exactly `context.previous` — a true rollback.
- `onSettled` invalidates to re-sync with server truth on both paths.
- The draft is cleared only in `mutate`'s `onSuccess` (LinkBox.tsx); on failure
  the inputs are intentionally preserved, and the error is surfaced via
  `isError`/`error` rather than swallowed.

Test coverage is strong and matches the behavior: loading/empty/success/error+retry
render states, the optimistic-success reconciliation, the failure rollback (row
removed, error shown, input preserved), and the empty-field guard (no request
fired). The two-`QueryClient` design is a deliberate isolation choice — both
surfaces use `queryKey: ["links"]` but live in separate providers, so there is
**no cache collision** (verified in `App.tsx` and `LinksPage.tsx`).

## Non-blocking observations (not merge blockers)

1. **`javascript:`-scheme href (self-XSS, low severity).** `LinkRow` renders
   `href={link.url}` from user-entered input (`src/LinkBox.tsx:8`). React does
   not strip `javascript:` URLs, so a user could store one and click it. Impact
   is limited to a single-user, self-entered link — worth a scheme allowlist
   later, but not a blocker for this app.
2. **Divergent record shapes on one page.** `LinkBox` reads `added_at` while the
   base `LinksPage` reads `createdAt` from the same `/api/links` endpoint
   (`src/components/LinksPage.tsx:15`). This is explicitly documented in the
   `App.tsx` header comment and is a pre-existing integration concern outside
   issue #9's scope (LinkBox itself never renders `added_at`).
3. **Enter-key double-submit edge.** The submit button is disabled while
   pending, but a disabled button doesn't block form submission via Enter, so a
   rapid second submit could stack a second optimistic entry. Minor; retries are
   off and the window is narrow.

## Decision

The feature is correct, safe, and its tests pass. Approving and merging.
