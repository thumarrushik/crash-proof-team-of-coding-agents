# Task Report — Issue #13: Improve duplicate link handling

## Scope (one sentence)

Make `LinkStore.save` idempotent so saving the same URL twice yields exactly one
row instead of two, and returns the already-stored row.

## Stated assumption (issue is deliberately underspecified)

"Behave sensibly" is read as **idempotent save**: saving a URL that is already
stored returns the existing row instead of appending a duplicate. Duplicates are
keyed on the exact URL string after trimming surrounding whitespace, so `"url"`
and `"  url  "` count as the same link. A small sensible-save guard rejects a
non-string or empty/whitespace-only URL with a `TypeError` rather than storing
junk. Deeper URL canonicalization is intentionally left out (see below).

**Context:** #13 is "Blocked by #2", which would introduce the save path. That
work is not present in this workspace's committed base (only the seed README is
committed), so there was no existing `save` to patch. I built the smallest
faithful slice of linkbox's save path — an in-memory `LinkStore` whose entries
are the "rows" the issue names — and fixed the duplicate behavior in it. If #2's
own store lands differently at merge time, this dedup logic transfers directly.

## Acceptance line → check

Saving the same URL twice yields exactly one stored row and the second `save`
returns the already-stored entry.

Proven by `test/linkStore.test.js` →
`saving the same URL twice does not create a second row`
(asserts `all().length === 1` and `second.id === first.id`).

## How it was verified (red → green)

I re-derived the bug: temporarily reverting `save` to the naive append-only
version the issue describes made `node --test` fail exactly the reported
scenario —

```
✖ saving the same URL twice does not create a second row   (rows: actual 2, expected 1)
✖ surrounding whitespace does not make a URL count as new
✖ save rejects a non-string or empty URL
ℹ pass 2  ℹ fail 3
```

Restoring the idempotent `save` turns the suite green. Final run (last workspace
action):

```
$ npm test        # runs: node --test
✔ saving a new URL creates one row and returns it
✔ saving the same URL twice does not create a second row
✔ surrounding whitespace does not make a URL count as new
✔ different URLs still create separate rows
✔ save rejects a non-string or empty URL
ℹ tests 5   ℹ pass 5   ℹ fail 0
```

## Files

- `src/linkStore.js` — `LinkStore` with idempotent `save(url)` (trim + dedup on
  exact URL) and `all()`.
- `test/linkStore.test.js` — 5 tests: new save, duplicate save, whitespace-
  equivalent duplicate, distinct URLs stay separate, invalid input rejected.
- `package.json` — declares the package and `test` script (`node --test`), no deps.

## Noticed, not changed

- **Deeper URL normalization** — `http://example.com` vs `.../`, scheme/host
  case, reordered query params, tracking-param stripping are still treated as
  distinct. Left out to keep the change minimal and non-presumptive; a follow-up
  if canonicalization is wanted.
- **Persistence** — the store is in-memory. A real datastore with a `UNIQUE`
  constraint on the URL column is the durable form of this fix, out of scope here.

## Residual risk

Low. Single self-contained module, no existing callers. Dedup is an O(n) linear
scan over `rows` — fine for a tiny app; a keyed index would matter only at scale.
