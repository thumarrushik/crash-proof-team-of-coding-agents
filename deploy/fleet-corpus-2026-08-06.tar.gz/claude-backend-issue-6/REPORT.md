# Task Report

## What was built
Added a `clicks` counter to each stored link, incremented by a new
`visit(link_id)` function — the logic-layer target of `GET /v0/links/{id}/visit`
(it raises `LinkNotFound`, the signal an HTTP transport maps to 404). Because the
endpoint addresses links by id and the store had none, each record now also
carries a stable `id`; both fields are additive, so old readers (e.g.
`markdown_export`) are unaffected. Pre-existing rows are covered by a new
versioned migration rail (`migrations.py`) — the stdlib analog of the team's SQL
migrate endpoint. Migration 1 backfills `id` and `clicks=0` onto legacy rows:
expand-first (never rewrites `url`/`title`/`added_at`), **batched** (writes after
every batch), **idempotent** (per-record "field missing" guard plus a recorded
applied-version, so a re-run is a clean no-op), and **resumable** (a durable
cursor in the `links.json.migrations.json` sidecar makes an interrupted run pick
up where it stopped, never restarting from zero or double-counting).

## How it was verified
- `python3 tests_backend.py` → `13/13 passed` (exit 0): clicks default to 0,
  `visit` increments and persists, touches only the target link, and rejects
  unknown/blank ids.
- `python3 tests_migrations.py` → `8/8 passed` (exit 0): backfill covers
  pre-existing rows, preserves existing fields, **applies twice cleanly**
  (`test_migrate_applies_twice_cleanly` asserts the second run changes nothing
  and data is byte-identical), is batched, resumes from its cursor without
  restarting, and never resets an existing count.
- `python3 tests_markdown.py` → `4/4 passed` (exit 0): the additive change did
  not break the markdown export.
- Live end-to-end run on a seeded legacy store: `migrations.migrate()` applied
  version 1 (2 rows backfilled to `clicks=0`), a second call was a no-op
  (`applied: []`), and two `visit` calls took the target link `0 → 1 → 2` while
  the other stayed at 0.

Residual risk: the store is a whole-file JSON read/write, so `visit` and the
backfill are O(n) in the store size — unchanged from the existing design, and
acceptable at this scale; no new N+1 was introduced.

## Files
- `links.py` — modified: `id`+`clicks` on new records, `_write_all` helper,
  `visit()`, `LinkNotFound`, and a `visit` CLI subcommand.
- `migrations.py` — created: versioned, idempotent, batched, resumable migration
  rail with the `id`/`clicks` backfill and a `migrate` CLI command.
- `tests_backend.py` — modified: added clicks/visit tests.
- `tests_migrations.py` — created: backfill coverage, idempotence, and
  resumability tests.
- `README.md` — modified: documented `clicks`/`visit` and the migration rail.
- `.gitignore` — modified: ignore the runtime `links.json.migrations.json`
  sidecar.
