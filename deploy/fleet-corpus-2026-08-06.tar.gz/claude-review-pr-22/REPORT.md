# Review — PR #22: Tags on links (add, list, filter) — closes #4

**Verdict: APPROVE.** The change is correct, safe, well-tested, and improves
the code health of the system. Both test suites are literal-green (evidence
below). No blocking findings.

## Scope reviewed

`git diff main...HEAD --stat` — 5 files, +727, all new:

| File | Read | Notes |
|---|---|---|
| `.gitignore` | ✅ | ignores `__pycache__/`, `*.pyc`, `links.json` — correct |
| `links.py` | ✅ | pure logic layer: add/list/normalize/backfill |
| `server.py` | ✅ | stdlib HTTP transport, canonical envelope |
| `tests_backend.py` | ✅ | 12 plain-assert tests over a real temp store |
| `tests_contract.py` | ✅ | 9 contract tests over real HTTP subprocess |

Every file was opened and read in full.

## Test evidence (final run = last workspace action)

```
$ python3 tests_backend.py    -> BACKEND_EXIT=0    12/12 passed
$ python3 tests_contract.py   -> CONTRACT_EXIT=0    9/9 passed
```

Both suites exit 0 with zero failures/errors. Tests are behavioral (drive the
real module / real HTTP subprocess, no mocks) and cover failure branches:
too-many-tags → `ERR_TOO_MANY_TAGS`, blank title → `ERR_SCHEMA_VALIDATION`,
non-list tags, malformed JSON, legacy-record backfill. They would fail if the
change were reverted.

## What I checked

- **Design/additivity** — `tags` is optional throughout; a client that omits
  it still gets a valid record with `tags: []` (`test_post_without_tags_still_works`).
  Clean logic/transport split; domain exceptions subclass `ValueError` and map
  to stable error codes in the envelope.
- **Normalization** — strip + lowercase + drop-blanks + dedup (first-seen
  order), cap applied *after* dedup (`normalize_tags`). Verified by tests.
- **Backward compat** — `_with_tags` backfills `tags: []` for legacy records
  missing the key *or* carrying a non-list value; tag filters correctly never
  match a tag-less legacy record.
- **Filtering** — `list_links(tag=...)` is case-insensitive; blank/whitespace
  tag is treated as "no filter". Server takes first `?tag=` value.
- **Error handling** — malformed JSON, non-dict body, and bad Content-Length
  all mapped to 422; `_guard` is a last-resort 500 net that logs loud and still
  renders the envelope. Corrupt store raises plain `ValueError` → 500 (fail loud,
  intended).

## Non-blocking findings

- `suggestion (non-blocking)`: `links.py add_link` / `server.py` — the server
  is `ThreadingHTTPServer`, but `add_link` does an unlocked read-modify-write
  of the whole JSON file (`_read_all()` → append → `json.dump`). Two concurrent
  POSTs can interleave so one overwrites the other's append (lost update). Fine
  for a "tiny" single-user app as scoped, but worth a file lock or a serializing
  mutex if concurrency ever grows. Not blocking: matches the documented
  tiny-stdlib design and is outside the tags feature's core.
- `nitpick (non-blocking)`: `server.py` — a 404 "no such route" is returned
  with `code: "ERR_MISSING_FIELD"`, which reads oddly for a routing miss vs. a
  missing body field. Cosmetic; no client contract in this PR depends on it.

## Decision

Correct, safe, tests green, code health improved. Approving and merging.
`tests_passed = true`.
