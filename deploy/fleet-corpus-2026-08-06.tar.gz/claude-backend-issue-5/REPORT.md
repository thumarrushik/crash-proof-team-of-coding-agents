# Task Report

## What was built
`GET /links` now serves `created_at` in two shapes side by side, because
changing a served field's type is a breaking contract change (api-contracts):
`GET /v0/links` keeps returning `created_at` as a unix epoch integer, and the
new `GET /v1/links` returns it as an ISO 8601 UTC string
(e.g. `"2023-11-14T22:13:20Z"`). `/v0` is never edited in place — it keeps
serving but carries RFC 8594 `Deprecation: true`, `Sunset: Sat, 06 Feb 2027
00:00:00 GMT`, and `Link: </v1/links>; rel="successor-version"` headers on every
response, and `/v1` carries none. The storage shape is unchanged: `links.py`
stores `created_at` as the canonical unix epoch integer and the HTTP layer
(`app.py`) serializes it per version, so this breaking API change needs no data
migration. Responses use the canonical `{data}` / `{error}` envelope; unknown
routes return a 404 envelope and unexpected errors a fail-loud 500 envelope
(never a bare HTML 500).

## How it was verified
- `python3 tests_backend.py` → `8/8 passed`, exit 0 (store data layer:
  `created_at` is an integer epoch, add/list, newest-first, blank-input
  rejection).
- `python3 tests_contracts.py` → `7/7 passed`, exit 0 (contract tests over real
  HTTP against the running server: `/v0` pins `created_at` as `int`, `/v1` pins
  it as an ISO 8601 string parsing back to the same instant, both describe the
  same link, `/v0` carries Deprecation/Sunset/successor `Link` headers, `/v1`
  carries none, unknown route → 404 envelope, corrupt store → fail-loud 500
  envelope). The traceback printed mid-run is the corrupt-store test exercising
  the fail-loud path; that test asserts and passes.
- Spot-checked the conversion directly: `app.to_iso8601_utc(1700000000)` →
  `2023-11-14T22:13:20Z`.
- Self-review hunts ran clean: no swallowed exceptions (the `do_GET` handler
  logs loud and returns the 500 envelope), no N+1 (one `list_links()` per
  request), inputs validated, only intended files changed.
- No frontend or end-to-end suites exist in this stdlib-only repo, so those
  layers are N/A.

## Residual risk
`links.list_links()` reads the whole JSON store unpaginated — inherent to the
existing tiny file store and unchanged by this issue (a date-format change), so
left as-is; a future issue should add pagination/bounds if the store grows.

## Files
- `app.py` (new) — stdlib HTTP service: `/v0/links` (epoch + sunset headers) and
  `/v1/links` (ISO 8601), canonical envelope, fail-loud error handling.
- `links.py` (new) — stdlib JSON-backed store; `created_at` as unix epoch integer.
- `tests_contracts.py` (new) — API contract tests over real HTTP pinning both
  shapes, the deprecation headers, and error envelopes.
- `tests_backend.py` (new) — store (data-layer) unit tests.
- `README.md` (modified) — documented the store, the two API versions, and the
  `/v0` deprecation/sunset window.
- `.gitignore` (new) — ignore `__pycache__/`, `*.pyc`, `links.json`.
