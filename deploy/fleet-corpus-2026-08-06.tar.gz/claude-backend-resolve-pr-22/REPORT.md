# PR #22 conflict resolution — `claude/issue-4` ← `main`

## Summary

Merged `origin/main` into `claude/issue-4` and resolved the two `add/add`
conflicts by hand. Both intents are preserved: the branch's tags feature
(issue #4) and everything main brought in (markdown export, docs, README
Development section).

## Conflicts resolved

### `links.py` (add/add)
- **Branch intent (HEAD):** `add_link(url, title, tags=None)` and
  `list_links(tag=None)` with tag normalization, the `MAX_TAGS` cap, the
  `LinkError`/`InvalidInput`/`TooManyTagsError` hierarchy with stable error
  codes, legacy-record tag backfill, and the extended CLI (`add ... [tag ...]`,
  `list [tag]`).
- **Base intent (main):** the simpler `add_link(url, title)` /
  `list_links()` store.
- **Resolution:** kept HEAD in full. HEAD is a strict superset of main — main
  added no behavior HEAD lacks (`add_link` still accepts `url, title`;
  `list_links()` still works with the default `tag=None`). No base behavior was
  lost.

### `tests_backend.py` (add/add)
- **Base intent (main):** the six original store tests.
- **Branch intent (HEAD):** those same six tests plus the tags tests and their
  registration in `_run()`.
- **Resolution:** kept HEAD in full (superset of main's test list).

## Files merged cleanly (from main, no conflict)
- `markdown_export.py`, `tests_markdown.py` — Markdown export feature.
- `docs/adr/0001-*`, `docs/adr/0002-*`, `docs/blueprint/link-preview.md`.
- `README.md` — main's Development section added; branch's links-store section
  preserved.

## Compatibility check
`markdown_export.to_markdown` reads only `title`/`url`, both still present on
every record produced by the tags-aware `add_link`, so the merged features are
compatible.

## Tests / checks

All suites pass after resolution:

- `tests_backend.py` — 12/12 passed
- `tests_markdown.py` — 4/4 passed
- `tests_contract.py` — 9/9 passed

**Total: 25/25 passing.**
